#!/usr/bin/env bash

# Generate requirements.txt file
echo "Generating requirements.txt..."
poetry install --no-interaction 
poetry export --no-interaction --without-hashes --format requirements.txt --output requirements.txt


ENV_VARS=$(grep -v '^#' .env.dev | xargs | tr ' ' ',')

# Upload source code to the GCP
echo "Deploying to GCP..."
gcloud functions deploy \
  lifex_answers_gcs_signup_cloud_function \
  --project lifex-backend \
  --region europe-west2 \
  --entry-point=add_user_on_create \
  --runtime=python311 \
  --memory=256MB \
  --timeout=9m \
  --update-env-vars "$ENV_VARS" \
  --allow-unauthenticated \
  --vpc-connector alloydb-connector \
  --trigger-event providers/firebase.auth/eventTypes/user.create \
  --trigger-resource=lifex-backend

