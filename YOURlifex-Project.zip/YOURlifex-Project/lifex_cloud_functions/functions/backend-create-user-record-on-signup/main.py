#!/usr/bin/env python
from sqlalchemy import Table
from configurations import (
    Users, 
    Session,
    logger,
)

def add_user(
        Users : Table = Users,
        user_id: str=None,
        email: str=None,
        user_name: str=None
    ):
    
    if None in (user_id, email):
        logger.error("User ID or email not provided.")
        return False
    
    logger.info("Adding user...")
    try:
        with Session() as session:
            user_data = {
                'id':user_id,
                'email':email,
                'user_name':user_name,
            }
            insert_stmt = Users.insert().values(user_data)
            result = session.execute(insert_stmt)
            session.commit()
            logger.info(f"Result: {result}")
            logger.info("User added successfully!")
    except Exception as e:
        logger.error(f"Error: {e}")
        return False

    return True

# [START functions_firebase_auth]
def add_user_on_create(data, context):
    """Triggered by creation or deletion of a Firebase Auth user object.
    Args:
           data (dict): The event payload.
           context (google.cloud.functions.Context): Metadata for the event.
    """
    logger.info(f"Function triggered by creation/deletion of user: {data['uid']}") #id
    logger.info(f"Email: {data['email']}")
    logger.info(f"Context: {context}")
    state = add_user(Users, user_id=data["uid"], email=data["email"], user_name=data["email"])

    logger.info(f"State: {state}")
    return state

if __name__ == '__main__':
    logger.info('Hello, World!')

    create_user = add_user_on_create(
        data={'uid':'abcde12345','email':'test@test.com'}, 
        context={}
    )
    logger.info(f"State: {create_user}")
