from sqlalchemy import create_engine
from sqlalchemy import text

from langchain_openai import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores.pgvector import PGVector
from langchain_community.document_loaders.sql_database import SQLDatabaseLoader, SQLDatabase

from configurations import settings
from configurations import logger

from time import sleep
from datetime import datetime



embeddings = OpenAIEmbeddings(model='text-embedding-3-large')

CONNECTION_STRING = PGVector.connection_string_from_db_params(
    driver="psycopg2",
    host=settings.VECTOR_DATABASE_HOST,
    port=int(settings.VECTOR_DATABASE_PORT),
    database=settings.VECTOR_DATABASE_NAME,
    user=settings.VECTOR_DATABASE_USERNAME,
    password=settings.VECTOR_DATABASE_PASSWORD,
)
APP_CONNECTION_STRING = PGVector.connection_string_from_db_params(
    driver="psycopg2",
    host=settings.APP_DATABASE_HOST,
    port=int(settings.APP_DATABASE_PORT),
    database=settings.APP_DATABASE_NAME,
    user=settings.APP_DATABASE_USERNAME,
    password=settings.APP_DATABASE_PASSWORD,
)


pgvector_db = PGVector(
    collection_name='llm',
    embedding_function=embeddings,
    connection_string=CONNECTION_STRING,
    )

app_db = create_engine(
    APP_CONNECTION_STRING,
    pool_pre_ping=True,
)

def run_query(query_text: str, engine, returns_records: bool=True):
    if returns_records:
        with engine.connect() as conn:
            results = conn.execute(text(query_text))
            records = []
            for _ in results.all():
                result_dict = tuple(zip(results.keys(), _))
                records.append(result_dict)
                
            logger.info(f'Ran query : {query_text}')
            logger.info(f'Results: {records}')
            return records
        
    else:
        with engine.connect() as conn:
            conn.execute(text(query_text))
            conn.commit()
            logger.info(f'Ran query : {query_text}')
            logger.info(f'Query executed successfully!')
            return True

    
def load_data(
        event,
        context,
        user_id: str = None,
        pgvector_db : PGVector = pgvector_db,
        app_db = app_db,
    ):

    #wait for 5 seconds to let the transcription finish
    sleep(5)

    # event_example 
    # {
    #     "name": "fd69a44d-d0e9-45f9-a948-30c270e7bacc/20240309_030153_488937-s01q003-1.mp3",
    # }
    if user_id is None and 'name' in event and '/' in event['name']:
        user_id = event['name'].split('/')[0]
    
    logger.info("Loading data...")
    logger.info("User: {}".format(user_id))
    logger.info(type(user_id))
    logger.info(f'User ID -> {user_id}')
    processing_date_time = str(datetime.now())
    # read app tables
    query = (
        "SELECT  distinct questions.stage_id, questions.question_number, questions.question, answer_text"
        " FROM question_answers"
        " left join users on question_answers.user_id = users.id"
        " left join questions on question_answers.question_id = questions.id"
        " where (question_answers.in_vector_db is null or question_answers.in_vector_db =false)"
        " and question_answers.answer_text is not null"
        " and questions.stage_id > 0"
        f" and question_answers.time_created <= '{processing_date_time}'::TIMESTAMP"
        f" and users.id = '{user_id}'"
    )
    logger.info("Query to run:")
    logger.info('query: {}'.format(query))

    def handle_none(value):
        return value or ""
    
    # read documents 
    app_db_reader = SQLDatabaseLoader(
        query=query,
        db=SQLDatabase(
            engine=app_db
        ),
        page_content_mapper=lambda x: handle_none(x['question']) + ': ' + handle_none(x['answer_text']),
        metadata_mapper=lambda x: {
            'user_id': user_id,
            'question_number':handle_none(x['question_number']),
            'stage': handle_none(x['stage_id']),
        },
    )
    logger.info('Query results')
    logger.info(app_db_reader.load())


    # prepare to add documents
    text_splitter = RecursiveCharacterTextSplitter(
        separators=["\n\n", "\n", "\\n"],
        chunk_size=500,
        chunk_overlap=100)
    
    documents = app_db_reader.load_and_split(
        text_splitter=text_splitter,
    )
    logger.info("Loaded {} documents".format(len(documents)))


    # add documents
    pgvector_db.add_documents(documents)

    logger.info(
        "Data loaded successfully! {} documents loaded!".format(len(documents))
    )

    # load user questions
    query = (
        "UPDATE question_answers"
        " SET in_vector_db = true"
        " where answer_text is not null"
        " and (in_vector_db is null or in_vector_db = false)"
        " and not answer_voice_record_path like '%-s00q%'"
        f" and question_answers.time_created <= '{processing_date_time}'::TIMESTAMP"
        f" and user_id = '{user_id}'"
    )
    update_table = run_query(
        query_text=query,
        engine=app_db,
        returns_records=False,
    )
    logger.info("Query executed successfully!")

    return "Vector DB & Answer status updated successfully: {}!".format(update_table)

if __name__ == "__main__":
    import pdb; pdb.set_trace();