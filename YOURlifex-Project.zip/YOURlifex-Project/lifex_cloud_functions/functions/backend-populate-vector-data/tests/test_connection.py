import psycopg2

from configurations import settings

# Establish a test connection to the database
conn = psycopg2.connect(
    dbname=settings.VECTOR_DATABASE_NAME,
    user=settings.VECTOR_DATABASE_USERNAME,
    password=settings.VECTOR_DATABASE_PASSWORD,
    host=settings.VECTOR_DATABASE_HOST
)

cur = conn.cursor()
cur.execute("SELECT * FROM pg_catalog.pg_tables;")

for table in cur.fetchall():
    print(table)


cur.close()
conn.close()
