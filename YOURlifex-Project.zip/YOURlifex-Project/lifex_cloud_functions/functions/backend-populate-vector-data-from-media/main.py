import tempfile
from sqlalchemy import (
    create_engine,
    text,
)
import re
import os

from langchain_openai import OpenAIEmbeddings
from langchain.vectorstores.pgvector import PGVector
from file_loader_utils import load_file_to_vector_db
from google.cloud import storage

from configurations import settings
from configurations import logger


# start connection strings

embeddings = OpenAIEmbeddings(model='text-embedding-3-large')
CONNECTION_STRING = PGVector.connection_string_from_db_params(
    driver="psycopg2",
    host=settings.VECTOR_DATABASE_HOST,
    port=int(settings.VECTOR_DATABASE_PORT),
    database=settings.VECTOR_DATABASE_NAME,
    user=settings.VECTOR_DATABASE_USERNAME,
    password=settings.VECTOR_DATABASE_PASSWORD,
)
APP_CONNECTION_STRING = PGVector.connection_string_from_db_params(
    driver="psycopg2",
    host=settings.APP_DATABASE_HOST,
    port=int(settings.APP_DATABASE_PORT),
    database=settings.APP_DATABASE_NAME,
    user=settings.APP_DATABASE_USERNAME,
    password=settings.APP_DATABASE_PASSWORD,
)
pgvector_db = PGVector(
    collection_name='llm',
    embedding_function=embeddings,
    connection_string=CONNECTION_STRING,
    )
app_db = create_engine(
    APP_CONNECTION_STRING,
    pool_pre_ping=True,
)

def run_query(query_text: str, engine, returns_records: bool=True):
    if returns_records:
        with engine.connect() as conn:
            results = conn.execute(text(query_text))
            records = []
            for _ in results.all():
                result_dict = tuple(zip(results.keys(), _))
                records.append(result_dict)
                
            logger.info(f'Ran query : {query_text}')
            logger.info(f'Results: {records}')
            return records
        
    else:
        with engine.connect() as conn:
            conn.execute(text(query_text))
            conn.commit()
            logger.info(f'Ran query : {query_text}')
            logger.info(f'Query executed successfully!')
            return True
        
def download_blob(
        bucket_name,
        source_blob_name,
        destination_file_name,
    ):
    """Downloads a blob from the bucket."""

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(source_blob_name)
    blob.download_to_filename(destination_file_name)

    logger.info(f"Blob {source_blob_name} downloaded to {destination_file_name}.")
    
def load_data(
        event,
        context,
        user_id: str = None,
        pgvector_db : PGVector = pgvector_db,
        app_db = app_db,
    ):

    # event_example 
    # {
    #     "name": "fd69a44d-d0e9-45f9-a948-30c270e7bacc/01/005/douglas_life.txt",
    # }

    stage:int | None = None
    question_number:int | None = None
    file_name:str | None = None

    # parse file name, stage and question number
    bucket_name = 'lifex-backend-user-files-dev'
    file_pattern = r"([a-zA-Z0-9\-]{7,36})\/(\d{2})\/(\d{3})\/([\w\s _\-,'\(\)]+\.[a-zA-Z0-9_]+)$"
    logger.info(event['name'])
    if (
        user_id is None
        and 'name' in event
        and '/' in event['name']
        and re.match(file_pattern, event['name'])
    ):
        user_id = event['name'].split('/')[0]
        stage = int(event['name'].split('/')[1])
        question_number = int(event['name'].split('/')[2])
        file_name = event['name'].split('/')[-1]
    else:
        raise Exception('Invalid file name')
    
    logger.info("Loading data...")
    logger.info("User: {}".format(user_id))
    logger.info(type(user_id))
    logger.info(f'User ID -> {user_id}')
    

    main_dir = os.getcwd()
    # create temporary directory to load file
    with tempfile.TemporaryDirectory() as temp_dir:
        os.chdir(temp_dir)
        # download file locally
        # use temp_dir, and when done:
        download_blob(
            bucket_name,
            event['name'],
            f"{temp_dir}/{file_name}",
        )
        logger.info("File downloaded successfully!")

        # load file to vector db
        load_file_to_vector_db(
            user_id = user_id,
            question_number = question_number,
            stage= stage,
            pgvector_db = pgvector_db,
            file_path =  f"{temp_dir}/{file_name}",
        )
        os.chdir(main_dir)
    


    # load user questions
    query = (
        "UPDATE question_media"
        " SET in_vector_db = true"
        " where (in_vector_db is null or in_vector_db = false)"
        f" and user_id = '{user_id}'"
        f" and media_path like '%{event['name']}%'"
    )
    update_table = run_query(
        query_text=query,
        engine=app_db,
        returns_records=False,
    )
    logger.info("Query executed successfully!")

    return "Vector DB & Media status updated successfully: {}!".format(update_table)

if __name__ == "__main__":
    import pdb; pdb.set_trace();