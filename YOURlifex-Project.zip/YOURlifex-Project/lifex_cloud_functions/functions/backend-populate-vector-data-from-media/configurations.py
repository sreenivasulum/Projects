import sys
import logging

from pydantic_settings import BaseSettings
from loguru import logger


# enivornment vars settings
class Settings(BaseSettings):
    DEBUG : bool = False
    OPENAI_API_KEY : str
    VECTOR_DATABASE_USERNAME : str
    VECTOR_DATABASE_PASSWORD : str
    VECTOR_DATABASE_HOST : str
    VECTOR_DATABASE_NAME : str = 'dev_vector_data'
    VECTOR_DATABASE_PORT : int
    VECTOR_DATABASE_SCHEME : str
    APP_DATABASE_USERNAME : str
    APP_DATABASE_PASSWORD : str
    APP_DATABASE_HOST : str
    APP_DATABASE_NAME : str
    APP_DATABASE_PORT : int

    class Config:
        env_file=('.env')
        env_file_encoding = 'utf-8'
        extra = 'ignore'


settings = Settings()


# logging
DEBUG = settings.DEBUG
class InterceptHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:  # pragma: no cover
        logger_opt = logger.opt(depth=7, exception=record.exc_info)
        logger_opt.log(record.levelname, record.getMessage())



# logging configuration
LOGGING_LEVEL = logging.DEBUG if DEBUG else logging.INFO
logging.basicConfig(
    handlers=[InterceptHandler(level=LOGGING_LEVEL)], level=LOGGING_LEVEL
)
logger.configure(handlers=[{"sink": sys.stderr, "level": LOGGING_LEVEL}])