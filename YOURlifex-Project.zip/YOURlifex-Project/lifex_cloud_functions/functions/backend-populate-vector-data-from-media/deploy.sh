#!/usr/bin/env bash

# Generate requirements.txt file
echo "Generating requirements.txt..."
poetry install --no-interaction 
poetry export --no-interaction --without-hashes --format requirements.txt --output requirements.txt


ENV_VARS=$(grep -v '^#' .env.dev | xargs | tr ' ' ',')

# Upload source code to the GCP
echo "Deploying to GCP..."
gcloud functions deploy \
  lifex_answers_populate_vector_db_cloud_function_from_media \
  --project lifex-backend \
  --region europe-west2 \
  --entry-point=load_data \
  --runtime=python311 \
  --memory=512MB \
  --timeout=9m \
  --update-env-vars "$ENV_VARS" \
  --allow-unauthenticated \
  --vpc-connector alloydb-connector \
  --trigger-bucket=lifex-backend-user-files-dev

