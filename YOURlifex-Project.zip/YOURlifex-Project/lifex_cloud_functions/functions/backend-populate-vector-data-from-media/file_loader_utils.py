from langchain.vectorstores.pgvector import PGVector
from langchain_community.document_loaders import (
    PyMuPDFLoader,
    TextLoader,
    Docx2txtLoader,
)
from langchain_text_splitters import RecursiveCharacterTextSplitter

from configurations import logger
import chardet


def is_readable_text(file_path: str) -> bool:
    with open(file_path, 'rb') as file:  # 'rb' for reading binary data
        rawdata = file.read()
        result = chardet.detect(rawdata)
        encoding = result['encoding']
        return encoding in ('ascii', 'utf-8', 'utf-16')  # Common text encodings
    

def load_data_from_pdf(
        file_path:str | None = None,
    ):
    loader= PyMuPDFLoader(file_path)
    documents = loader.load()
    return documents

def load_data_from_microsoft_word(
        file_path:str | None = None,
    ):
    loader= Docx2txtLoader(file_path)
    documents = loader.load()
    return documents

def load_data_from_text(
        file_path:str | None = None,
    ):
    loader= TextLoader(file_path)
    documents = loader.load()
    return documents


file_endings_map = {
    'pdf': load_data_from_pdf,
    'docx': load_data_from_microsoft_word,
}

def load_data_from_file(file_path):
    file_extension = file_path.split('.')[-1]
    if is_readable_text(file_path):
        return load_data_from_text(file_path)    
    elif file_extension in file_endings_map:
        load_data : function = file_endings_map[file_extension]
        return load_data(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_path}")

def load_documents_to_pgvector(
        user_id: str | None = None,
        question_number: int = 2,
        stage: int = 1,
        pgvector_db : PGVector | None = None,
        documents = None,
    ):
    text_splitter = RecursiveCharacterTextSplitter(
        separators=["\n\n", "\n", "\\n"],
        chunk_size=500,
        chunk_overlap=100,
    )
    docs = text_splitter.create_documents(
        texts=[d.page_content for d in documents],
        metadatas=[
            {
            'user_id': user_id,
            'question_number': question_number,
            'stage': stage,
            } for _ in documents
        ],
    )

    # add documents
    pgvector_db.add_documents(docs)
    logger.info("Loaded {} documents".format(len(docs)))
    logger.info("Data loaded successfully!")
    return 'Documents loaded successfully!'

def load_file_to_vector_db(
        user_id: str | None = None,
        question_number: int = 2,
        stage: int = 1,
        pgvector_db : PGVector = None,
        file_path: str | None = None,
    ):

    documents = load_data_from_file(file_path)
    return load_documents_to_pgvector(
        user_id,
        question_number,
        stage,
        pgvector_db,
        documents,
    )