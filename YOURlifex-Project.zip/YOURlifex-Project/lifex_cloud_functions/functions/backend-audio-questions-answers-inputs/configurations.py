import sys
import logging

from pydantic_settings import BaseSettings
from loguru import logger

from sqlalchemy import Table, create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import MetaData


# enivornment vars settings
class Settings(BaseSettings):
    DEBUG : bool = False
    OPENAI_API_KEY : str
    APP_DATABASE_USERNAME : str
    APP_DATABASE_PASSWORD : str
    APP_DATABASE_HOST : str
    APP_DATABASE_NAME : str
    APP_DATABASE_PORT : int
    ELEVENLABS_API_KEY : str = ''
    DEFAULT_VOICE_ID : str = 'tKqtw8dKxOcTcta5csz8'

    class Config:
        env_file=('.env', '.env.dev')
        env_file_encoding = 'utf-8'
        extra = 'ignore'


settings = Settings()


# logging
DEBUG = settings.DEBUG
class InterceptHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:  # pragma: no cover
        logger_opt = logger.opt(depth=7, exception=record.exc_info)
        logger_opt.log(record.levelname, record.getMessage())



# logging configuration
LOGGING_LEVEL = logging.DEBUG if DEBUG else logging.INFO
logging.basicConfig(
    handlers=[InterceptHandler(level=LOGGING_LEVEL)], level=LOGGING_LEVEL
)
logger.configure(handlers=[{"sink": sys.stderr, "level": LOGGING_LEVEL}])




# Database connection details
db_user = settings.APP_DATABASE_USERNAME
db_password = settings.APP_DATABASE_PASSWORD
db_host = settings.APP_DATABASE_HOST
db_name = settings.APP_DATABASE_NAME

# Connection String (Adjust for your database type)
engine = create_engine(
    f"postgresql://{db_user}:{db_password}@{db_host}/{db_name}",
    pool_pre_ping=True,
)

# fetech metadata
metadata = MetaData()
metadata.reflect(bind=engine)

# provide session and answers table references
QuestionAnswers = Table('question_answers', metadata)
Users = Table('users', metadata)
Session = sessionmaker(bind=engine)
