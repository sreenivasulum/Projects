#!/usr/bin/env python
import httpx
from configurations import logger, settings
from google.cloud import storage
from io import BytesIO
import openai
from configurations import (
    QuestionAnswers,
    Session,
    Users,
)


def update_transcription(event, context):
    """Background Cloud Function to be triggered by Cloud Storage.
       This generic function logs relevant data when a file is changed,
       and works for all Cloud Storage CRUD operations.
    Args:
        event (dict):  The dictionary with data specific to this type of event.
                       The `data` field contains a description of the event in
                       the Cloud Storage `object` format described here:
                       https://cloud.google.com/storage/docs/json_api/v1/objects#resource
        context (google.cloud.functions.Context): Metadata of triggering event.
    Returns:
        None; the output is written to Cloud Logging
    """

    try:
        logger.info('Hello, Cloud Storage!')
        logger.info(f"Event ID: {context.event_id}")
        logger.info(f"Event type: {context.event_type}")
        logger.info("Bucket: {}".format(event["bucket"]))
        logger.info("File: {}".format(event["name"]))
        logger.info("Metageneration: {}".format(event["metageneration"]))
        logger.info("Created: {}".format(event["timeCreated"]))
        logger.info("Updated: {}".format(event["updated"]))

        bucket_name = event["bucket"]
        file_name = event["name"]
        openai_api_key = settings.OPENAI_API_KEY

        transcription = transcribe_gcs_audio(bucket_name, file_name, openai_api_key)
        logger.info(transcription)

        update_question_answer_table(file_name, transcription, QuestionAnswers=QuestionAnswers,)

        if 's00q001' in file_name:
            files = list_stage_zero_file_names_from_gcs(
                user_id= file_name.split('/')[0],
                bucket_name=bucket_name,
            )

            clone_response_json = clone_voice(files, file_name.split('/')[0], bucket_name)

            logger.info(clone_response_json)
            voice_id = clone_response_json['voice_id'] 
            update_user_table(
                voice_id, 
                user_id=file_name.split('/')[0], 
                Users=Users
            )

    except KeyError as e:
        print(f"Key error, {e} not found in event data.")
        logger.error(e)


 
def transcribe_gcs_audio(bucket_name, file_name, openai_api_key):
    """Transcribes an MP3 file from GCS using the OpenAI Whisper API."""

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_name)

    # Download audio file data into memory
    audio_data = blob.download_as_bytes()
    audio_file = BytesIO(audio_data)

    openai.api_key = openai_api_key
    client = openai.OpenAI() 
    transcription = client.audio.transcriptions.create(
        model="whisper-1",
        file=(file_name,audio_file),
        language="en",
    )

    return transcription.text

def clone_voice(
        file_names: list,
        user_id: str,
        bucket_name: str,
    ):

    data = {
        "name": "User " + user_id,
    }

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)

    files_string_list = []
    for file_name in file_names:
        blob = bucket.blob(file_name)

        # Download audio file data into memory
        audio_data = blob.download_as_bytes()
        audio_file = BytesIO(audio_data)

        files_string_list.append(
            (
                "files",(file_name, audio_file)
            )
        )
    headers = {
        "xi-api-key": settings.ELEVENLABS_API_KEY,
    }

    with httpx.Client() as client:
        response = client.post(
            "https://api.elevenlabs.io/v1/voices/add",
            headers=headers,
            data=data,
            files=files_string_list,
            timeout=180,
        )

    if response.status_code != 200:
        logger.error(response.json())
        raise Exception("Failed to clone voice.")
    else:
        old_voice_id = get_user_voice_id(user_id)
        if old_voice_id:
            logger.info(
                f"User voice found. Deleting voice... VID: {old_voice_id}"
            )
            delete_voice(
                old_voice_id,
                settings.ELEVENLABS_API_KEY,
            )
    
    return response.json()

def get_user_voice_id(
        user_id: str,
):
    with Session() as session:
        voice_id = session.query(Users.c.voice_id).filter(Users.c.id == user_id).one_or_none()

        if voice_id:
            return voice_id[0] 
    
def delete_voice(
        voice_id: str,
        api_key: str = settings.ELEVENLABS_API_KEY,
        ) -> bool:
    """Deletes a voice from ElevenLabs using the provided API key.

    Args:
        voice_id: The unique identifier of the voice to delete.
        api_key: Your ElevenLabs API key for authentication.

    Returns:
        True if the deletion was successful, False otherwise.
    """

    headers = {
        "xi-api-key": api_key,
        "accept": "application/json",
    }  # Ensure these headers are correct

    # skip default voice
    if voice_id == settings.DEFAULT_VOICE_ID:
        voice_id = 'default'
    
    url = f"https://api.elevenlabs.io/v1/voices/{voice_id}"  # Endpoint for deletion

    if voice_id == 'default':
        logger.info('Default voice so skipping default voice deletion')
        return True
    
    with httpx.Client() as client:
        response = client.delete(url, headers=headers)

        if response.status_code == 200:
            logger.info(f'Voice deleted successfully! {voice_id}')
            return True
        else:
            logger.error(
                f"Failed to delete voice with ID {voice_id}. Error: {response.status_code} - {response.text}"
                )
            raise Exception("Failed to delete voice.")

def list_stage_zero_file_names_from_gcs(user_id, bucket_name, limit = 25):

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)

    file_names = []
    for blob in bucket.list_blobs(prefix=user_id + "/"):
        if 's00q00' in blob.name:
            file_names.append(blob.name)

    return file_names[-limit:]


def update_question_answer_table(filename, transcription, QuestionAnswers=QuestionAnswers):

    with Session() as session:
        answer_to_edit = session.query(QuestionAnswers).filter(QuestionAnswers.c.answer_voice_record_path.contains(filename))

        if answer_to_edit.first():
            answer_to_edit.update({'answer_text':transcription})
            session.commit()
            logger.info("Answer updated successfully!")
        else:
            logger.error("User not found.")
    return True

def update_user_table(voice_id, user_id, Users=Users):

    with Session() as session:
        user_to_edit = session.query(Users).filter(Users.c.id == user_id)

        if user_to_edit.first():
            user_to_edit.update({'voice_id':voice_id})
            session.commit()
            logger.info("User updated successfully!")
        else:
            logger.error("User not found.")
    return True
    
if __name__ == '__main__':
    logger.info('Hello, World!')

    # pick a local db file that exists in a local db and in the dev bucket
    bucket_name = 'lifex-backend-audio-inputs-dev' 
    file_name = '01a6fbca-6c20-4c32-92b2-35cccbd734a9/20240306_235946_803617-s00q002-1.mp3'
    # openai_api_key = settings.OPENAI_API_KEY

    

    # transcription = transcribe_gcs_audio(bucket_name, file_name, openai_api_key)
    # print(transcription)

    # update_question_answer_table(QuestionAnswers, file_name, transcription)

    clone_voice([file_name], '01a6fbca-6c20-4c32-92b2-35cccbd734a9', bucket_name)
