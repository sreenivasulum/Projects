Model Decisions and Architecture

## Data Model Decisions

What metrics do we need?
1. Progress bar per stage per user
2. Average audio length per stage.

Glossary of terms:
- `user`: app users and has an id and answers.
- `question`: questions and has an id and its own table.
    - `stage`: questions have stages and each stage has an id and its own table.
- `question_stages`: questions stages and has an id and its own table plus question foreign id.
- `question_answer`: answers per question per user and has an id and its own table plus question foreign id.
