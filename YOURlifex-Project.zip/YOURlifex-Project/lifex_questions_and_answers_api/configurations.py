from pydantic_settings import BaseSettings
import os


def get_env_file_path(dot_env_file):
    return os.path.join(os.path.dirname(__file__), dot_env_file)

class Settings(BaseSettings):
    APP_DATABASE_USERNAME : str = ''
    APP_DATABASE_PASSWORD : str = ''
    APP_DATABASE_HOST : str = ''
    APP_DATABASE_NAME : str = ''

    class Config:
        env_file = get_env_file_path('.env')
        env_file_encoding = 'utf-8'
        extra = 'ignore'


settings = Settings()