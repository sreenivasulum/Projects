
Revision Migration: To create a new migration revision, use the following command:
```bash
PYTHONPATH=.. alembic revision --autogenerate -m "Your_migration_message"
```
This will create a new migration file with the changes detected in your models.

```bash
alembic upgrade head
```
This command applies any unapplied migrations to bring the database schema up to the latest version.

Downgrading: To downgrade to a previous revision, use the following command:

```bash 
alembic downgrade -1
```
To downgrade to a specific revision, use the following command:
```bash
alembic downgrade <revision_id>
```

