from typing import List
from fastapi.responses import HTMLResponse
from langchain.docstore.document import Document

from fastapi import APIRouter, Depends, HTTPException, Path
from sqlalchemy.orm import Session
from sqlalchemy import desc

from services.sentino_api_interface import (
    assess_personality_traits,
    scoring_json_to_text,
)
from core.config import DEFAULT_USER_ID, extract_stage_and_question_number, get_vector_store, logger, DEBUG
from core.config import create_database_session
from core.events import get_connection_manager, get_timer
from services.speech_to_text import get_speech_to_text, SpeechToText
from models.questions_answers_model import Question, QuestionAnswer, PersonalityAssessments




router = APIRouter()
BIG_FIVE_QUESITONS_STAGE = 20

# TODO: IF SITUATION IS TRUE ASSESS PERSONALITY USING BOOLEAN FUNCTION BELOW
# TODO: TEST PATHS
# TODO: BUILD FRONTEND TO ASSESS PERSONALITY
# TODO: UPGRADE QUERY CONTEXT TO INTEGRATE PERSONALITY SUMMARY

def add_answer_to_langchain_document(
    answer_text:str,
    user_id:str, 
    question_number: int, question:str, stage_id:int
    ):
    """
    A function that adds an answer to a langchain document.

    Parameters:
        answer_text: str - The text of the answer.
        user_id: str - The user ID associated with the answer.
        question_number: int - The number of the question.
        question: str - The text of the question.
        stage_id: int - The ID of the stage.

    Returns:
        Document - A document object representing the answer added to the langchain document.
    """
    question_prefix = (
        "Answer with stating the degree of agreement or disagreement with this statement choosing" 
        " from “strongly agree”, “agree”, “neutral”, “disagree” or “strongly disagree”."
    )
    vector_db_text = question_prefix + ' statement:' + question + '-> answer:' + answer_text
    metadata={
            'user_id': user_id,
            'question_number':question_number,
            'stage': stage_id,
    }
    document =  Document(page_content=vector_db_text, metadata=metadata)
    return document

#check if it is worth having a personality assessment by checking if users have answered
# all the personality questions after the latest personality assessment
def check_if_user_ran_personality_assessment(
    db: Session=Depends(create_database_session),
    user_id: str=DEFAULT_USER_ID,
):
    """
    A function to check if a user has answered all the personality questions.

    Parameters:
        db: Session - Database session.
        user_id: str - User ID associated with the answers.

    Returns:
        True if the user has answered all the personality questions.
    """

    #check when is the latest personality assessment
    #query PersonalityAssessments table to get the latest assessment time
    lastest_assessment_time = db.query(PersonalityAssessments.time_created).order_by(
        desc(PersonalityAssessments.time_created)).filter(
        PersonalityAssessments.user_id == user_id,
    ).limit(1).one_or_none()

    lastest_assessment_time = lastest_assessment_time[0] if lastest_assessment_time else None

    run_assessment : bool = False
    #check if all the questions in stage 20 (BIG FIVE STAGE) had been answered after the latest assessment
    if lastest_assessment_time:
        #count distinct questions in BIG_FIVE_STAGE
        big_five_stage_questions_length : int = db.query(Question.question_number).filter(
            Question.stage_id == BIG_FIVE_QUESITONS_STAGE
        ).distinct().count()

        #count distinct questions in BIG_FIVE_STAGE that have been answered after the latest assessment
        unassessed_answered_questions_length = db.query(Question.question_number).join(
            Question, QuestionAnswer.question_id == Question.id
        ).filter(
            QuestionAnswer.user_id == user_id,
            Question.stage_id == BIG_FIVE_QUESITONS_STAGE,
            QuestionAnswer.time_created > lastest_assessment_time
        ).distinct().count()

        run_assessment = big_five_stage_questions_length == unassessed_answered_questions_length
    
    return run_assessment

@router.get('/personality/bigfive_assessment/',
            name="text_answers:bigfive_personality_assessment",
            response_class=HTMLResponse
)
async def read_root():
    html_content = ''
    import os
    logger.info(os.getcwd())
    logger.info(os.listdir())
    with open('templates/questionnaire.html', 'r') as html:
        html_content = html.read()

    return HTMLResponse(content=html_content, status_code=200)

@router.post("/personality/answer/", name="text_answers:personality")
async def answer_personality_questions(
    answers: List[dict], 
    db: Session=Depends(create_database_session),
    user_id: str=DEFAULT_USER_ID,
):
    """
    A function to log answers provided for personality questions.

    Parameters:
        answers: List[dict] - A list of dictionaries containing question details like question_id, question_stage, question_number, question_text, and answer_text. That is:
            # structure -> {question_id: int, question_stage : int, question_number: int, question_text: str, 
            # answer_text: str[strongly agree | agree | neutral | disagree |  strongly disagree]}
        db: Session - Database session.
        user_id: str - User ID associated with the answers.

    Returns:
        True if the answers are logged successfully.
        Raises:
            HTTPException: If an error occurs during execution.
    """
    try:
        def add_answer_to_vector_store(answers, user_id):
            """
            A function to add answers to the vector store.
            """
            vector_documents : list = []
            for answer in answers:
                question_id = answer["question_id"]
                question_number = answer["question_number"]
                question_text = answer["question_text"]
                question_stage = answer["question_stage"]
                answer_text = answer["answer_text"]
                

                answer = QuestionAnswer(
                    question_id=question_id,
                    answer_text=answer_text,
                    user_id=user_id,
                    in_vector_db=True,
                )
                db.add(answer)
                db.commit()

                document = add_answer_to_langchain_document(
                answer_text=answer_text, 
                user_id=user_id, 
                question_number=question_number, 
                question=question_text,
                stage_id= question_stage,
                )

                vector_documents.append(document)

                logger.debug(
                    f"User ID: {user_id}"
                    f"Question ID: {question_id} \n"
                    f"Answer Text: {answer_text} \n"
                    f"Answer Logging in progress"
                )

            db.commit()
            db.close()

            # add documents
            pgvector_db = get_vector_store()
            pgvector_db.add_documents(vector_documents)

            return True
        

        #execute
        add_answer_to_vector_store(answers, user_id)

        personality_assessment_needed = not check_if_user_ran_personality_assessment(
                db,
                user_id,
            )
        logger.info(
            personality_assessment_needed
        )
        if personality_assessment_needed:
            logger.info('please run personality assessment')
            unassessed_answered_questions = db.query(
                    Question.question,QuestionAnswer.answer_text
                ).join(
                    Question, QuestionAnswer.question_id == Question.id
                ).filter(
                    QuestionAnswer.user_id == user_id,
                    Question.stage_id == BIG_FIVE_QUESITONS_STAGE
                ).order_by(
                    QuestionAnswer.time_created.desc()
                ).all()
            #assess_personality_traits
            unassessed_answered_questions_list = list(unassessed_answered_questions)
            unassessed_answered_questions_sentino_compatible_list = [{"item":q,"response":r.lower()} for q,r in unassessed_answered_questions_list]
            scoring_json = assess_personality_traits(
                unassessed_answered_questions_sentino_compatible_list
            )
            logger.info(
                scoring_json,
            )

            test=scoring_json_to_text(scoring_json)
            logger.info(test)
            # add personality assesment result
            personlity_assesment = PersonalityAssessments(
                user_id=user_id,
                test_type="big5",
                assessment_result_summary=test,
                assessment_result_raw=str(scoring_json),

            )

            # db.add(personlity_assesment)
            # db.commit()
            # db.close()

        logger.info(
            "All inprogress questions logged for"
            f"User ID: {user_id}"
        )

        return True

    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=500, detail="An error occurred during execution.")