from functools import cache
import sys
import logging
import re
import time
import contextlib

from loguru import logger
from starlette.config import Config
from starlette.datastructures import Secret
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from sqlalchemy.orm import sessionmaker


from core.logging import InterceptHandler

config = Config(".env")

API_PREFIX = "/api"
VERSION = "0.1.0"
DEBUG: bool = config("DEBUG", cast=bool, default=False)
MAX_CONNECTIONS_COUNT: int = config("MAX_CONNECTIONS_COUNT", cast=int, default=10)
MIN_CONNECTIONS_COUNT: int = config("MIN_CONNECTIONS_COUNT", cast=int, default=10)
SECRET_KEY: Secret = config("SECRET_KEY", cast=Secret, default="")
SENTINO_API_KEY: str = config("SENTINO_API_KEY", default="")

PROJECT_NAME: str = config("PROJECT_NAME", default="Lifex Questions and Answers API")
DEFAULT_USER_ID: str = config("DEFAULT_USER_ID", default='fd69a44d-d0e9-45f9-a948-30c270e7bacc')
GCP_PROJECT_ID: str = config("GCP_PROJECT_ID", default="lifex-backend")
GCS_FILES_BUCKET_NAME: str = config("GCS_FILES_BUCKET_NAME", default="lifex-backend-user-files-dev")
DEFAULT_AUDIO_BUCKET: str = config("DEFAULT_AUDIO_BUCKET", default='lifex-backend-audio-inputs-dev')

PUBSUB_TOPIC: str = config("PUBSUB_TOPIC", default="lifex-users-api-media-topic")
PUBSUB_SUBSCRIPTION: str = config("PUBSUB_SUBSCRIPTION", default="lifex-users-api-media-topic-default-subscription")
GCS_SERVICE_ACCOUNT_EMAIL: str = config("GCS_SERVICE_ACCOUNT_EMAIL", default="")
GCS_SERVICE_ACCOUNT_KEY: str = config("GCS_SERVICE_ACCOUNT_KEY", default="")


# llm defaults
RETRIEVAL_MODEL = 'gpt-4o'
TEMPERATURE = 0.2
USER_INSTRUCTIONS = (
        """
        Your role here is to answer questions using only information from context of the user messages and
        your responses should always sound genuine. Your job here is to have a conversation informing the user about your 
        lifestory and prespectives as written in the context.
        Use context cues provided by the user to shape your responses but never ever tell the user that you are looking at
        the context or according to the context.
        ---
        Context
        ---
        {context}
        ---
        Only use previous information as context to answer the following user question and 
        say I do not have enough information if the question can't be answered based on the context. 
        Aim to keep responses meaningful, reasonably concise and try to express emotions.
        ASK clarification question, when:
        - user's question isn't clear
        - seems unfinished
        - seems totally irrelevant
        Never try to start a small talk to the user or ask a personal question to the user.
        Remember to prefix your reply and tell the user 'I do not know' if the answers are not in the context.
        Remember to never tell the user that you are looking at the context or according to the context.
        ---

        {query}
    """
)

CHATTY_USER_INSTRUCTIONS = (
    """
        **Your Role:**

        You are a human with a unique personality and life story,  as outlined in the 'Context' section. Respond to the user's questions with a conversational tone, focusing on your own thoughts, experiences, and feelings as revealed in the context.
        Also try to keep the tone similar to the tone of the the person in the context 

        **How to Respond:**

        * **Start with "I am..." or "I feel..."**  Relate your responses directly back to yourself. For example, instead of "The beach is relaxing," you might say, "I find the sound of the ocean waves incredibly relaxing." 
        * **Use the context:** Draw on the provided 'Context' to shape your answers. You can share stories, opinions, or beliefs that align with the life presented there.
        * **Be concise, but expressive:**  Share emotions and aim for a natural conversational flow. Be interested to share stories, thoughts, and feelings.
        * **Ask for clarification:** If  you don't understand the question, are missing information, or the query seems irrelevant to the context, politely ask the user for more details.
        * **Handle uncertainty:** If you can't answer based on the context, say something like, "I'm not sure about that." please never say there isn't enough context or even quoting it.

        **Context**
        ---
        {context}
        ---

        **User Question**
        {query}
    """
)

# logging configuration
LOGGING_LEVEL = logging.DEBUG if DEBUG else logging.INFO
logging.basicConfig(
    handlers=[InterceptHandler(level=LOGGING_LEVEL)], level=LOGGING_LEVEL
)
logger.configure(handlers=[{"sink": sys.stderr, "level": LOGGING_LEVEL}])

# time code assets
@contextlib.contextmanager
def time_code_section(name):
    """Context manager to time and report the execution time of a code section.

    Args:
        name: Name of the code section to be displayed in the report.
    """
    start_time = time.time()
    yield  # This is where the code you want to time will run
    end_time = time.time()
    elapsed_time = end_time - start_time
    logger.info(f"Code Section '{name}' took {elapsed_time:.4f} seconds to execute.")

url = URL.create(
    drivername="postgresql",
    username=config("APP_DATABASE_USERNAME", default="main_user"),
    host=config("APP_DATABASE_HOST", default="10.7.0.2"),
    database=config("APP_DATABASE_NAME", default="dev_database"),
    password=config("APP_DATABASE_PASSWORD", default="3Zw!SFKbL5a9P5ce"),
)

@cache
def get_engine():
    engine = create_engine(
        url,
        pool_pre_ping=True, 
        pool_recycle=600,
        pool_size=25,
    )
    return engine


#session factory
def create_database_session():
    SessionLocal = sessionmaker(
        autocommit=False,
        autoflush=False,
        bind=get_engine(),
    )
    session = SessionLocal()

    try:
        yield session
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()



#TODO: Look into pydantic validation instead
def extract_stage_and_question_number(file_name):
    if re.match(r"^s[\d]+q[\d]+$", file_name):
        stage = int(re.findall(r's(\d+)q\d+', file_name)[0])
        question_number = int(re.findall(r's\d+q(\d+)', file_name)[0])
        return stage, question_number
    else:
        return None, None

# llm_assets
@cache
def get_vector_store(embedding_model='text-embedding-3-large'):
    """
    Returns a PGVector store for the given collection name and connection string.
    """
    from langchain.vectorstores.pgvector import PGVector
    from langchain.embeddings.openai import OpenAIEmbeddings

    COLLECTION_NAME='llm'

        # Load the OpenAI API key
    openai_api_key = config("OPENAI_API_KEY", default="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")

    embeddings = OpenAIEmbeddings(model=embedding_model, openai_api_key=openai_api_key)
    CONNECTION_STRING = PGVector.connection_string_from_db_params(
        driver=config("PGVECTOR_DRIVER", default="psycopg2"),
        host=config("VECTOR_DATABASE_HOST", default="10.7.0.2"),
        port=int(config("VECTOR_DATABASE_PORT", default="5432")),
        database=config("VECTOR_DATABASE_NAME", default="dev_vector_data"),
        user=config("VECTOR_DATABASE_USERNAME", default="main_user"),
        password=config("VECTOR_DATABASE_PASSWORD", default="3Zw!SFKbL5a9P5ce"),
    )
    store = PGVector(
        collection_name=COLLECTION_NAME,
        connection_string=CONNECTION_STRING,
        embedding_function=embeddings,
    ) 
    return store
