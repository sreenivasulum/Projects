from fastapi import APIRouter

from api.routes import questions_answers
from api.routes import qa_websocket_routes
from api.routes import questions_answers_personality

router = APIRouter()
router.include_router(questions_answers.router, tags=["questions_answers"], prefix="/v1")
router.include_router(qa_websocket_routes.router, tags=["qa_websocket_routes"], prefix="/v1")
router.include_router(questions_answers_personality.router, tags=["questions_answers_personality"], prefix="/v1")