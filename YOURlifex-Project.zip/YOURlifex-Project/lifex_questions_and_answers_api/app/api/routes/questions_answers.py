from datetime import datetime, timedelta
import json
import re
from typing import List
from sqlalchemy import desc, select, text
from sqlalchemy.orm import Session
from langchain_community.chat_models import ChatOpenAI
from fastapi import (
    File,
    UploadFile,
    Depends,
    APIRouter,
    HTTPException,
    Path,
    Body,
    Response,
)
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse

from core.config import (
    CHATTY_USER_INSTRUCTIONS,
    DEFAULT_USER_ID,
    RETRIEVAL_MODEL,
    TEMPERATURE,
    USER_INSTRUCTIONS,
    extract_stage_and_question_number,
    create_database_session,
    logger,
    get_vector_store,
    time_code_section,
)
from services.text_to_speech import generate_audio
from services.gcp_jobs import (
    GCS_FILES_BUCKET_NAME,
    download_gcs_file_as_bytes,
    upload_file_to_gcp_storage,
    generate_signed_url_v4,
)
from services.gcp_pubsub_jobs import (
    publish_messages,
    pull_messages,
    ack_message,
)
from models.local_models import HealthResponse
from models.questions_answers_model import (
    Question,
    QuestionAnswerMedia,
    ChatInteractions,
)
from models.questions_answers_model import QuestionStage
from models.questions_answers_queries import (
    get_user_stage_progress_statement,
    get_user_progress_statement,
)
from langchain.chains import RetrievalQA
from langchain_community.llms import OpenAI
from langchain_core.prompts import PromptTemplate


router = APIRouter()
PROFILE_PHOTO_QUESTION_ID = 454

@router.get(
    "/health",
    response_model=HealthResponse,
    name="health:get-data",
)
async def health():
    return HealthResponse(status=True)

@router.get(
    "/profile_picture",
    name="response:get-profile-picture",
)
async def get_profile_picture(
    user_id: str = DEFAULT_USER_ID,
    db: Session = Depends(create_database_session),
):
    image_path_statement = select(
            QuestionAnswerMedia.media_path,
            QuestionAnswerMedia.media_type,
    ).filter(
        QuestionAnswerMedia.user_id == user_id,
        QuestionAnswerMedia.question_id == PROFILE_PHOTO_QUESTION_ID,
        QuestionAnswerMedia.media_type.in_(
            ['image/png', 'image/jpg', 'image/jpeg', 'image/tiff', 'image/bmp', 'image/gif']
        ),
    ).order_by(
        desc(QuestionAnswerMedia.time_created)
    ).limit(1)
    statement_execution = db.execute(image_path_statement)
    db.close()

    try:
        image_path, image_media_type = statement_execution.one()
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=404, detail="Profile picture not found")

    #download image from gcs
    image_path_parts = re.search(r"^gs://([^/]+)/(.*)", image_path)

    if not image_path_parts:
        logger.warning(f'Bad file format: {image_path}')
        raise HTTPException(status_code=404, detail="Profile picture not found")
    
    buckets_name, blob_name = image_path_parts.groups()
    image_bytes = download_gcs_file_as_bytes(buckets_name, blob_name)
    
    return Response(
        content=image_bytes, 
        media_type=image_media_type,
        headers={
            "Cache-Control": "public, max-age=7200, s-maxage=7200", 
        },
    )


@router.post(
    "/response_api/{user_id}/",
    name="response:post-data",
)
async def get_conversation_answers(
    user_id: str=Path(...),
    payload: dict = Body(
        ...,
        example={"conversation_id": "example_id", "human_input": "What's the weather today?"}
    ),
    db: Session = Depends(create_database_session),
):
    conversation_id = payload.get("conversation_id") or 1
    query = payload.get("human_input")

    if not conversation_id or not query:
        logger.error("conversation_id and human_input are required")
        return {"error": "conversation_id and human_input are required"}  # Handle missing input

    store = get_vector_store()
    llm = ChatOpenAI(
        model_name=RETRIEVAL_MODEL,
        temperature=TEMPERATURE,
    )
    retriever = store.as_retriever(
        search_kwargs={
            'filter':{'user_id':user_id}
        }
    )
    prompt = PromptTemplate(
        template=CHATTY_USER_INSTRUCTIONS,
        input_variables=['context'],
        partial_variables={'query':query},
    )
    qa_chain = RetrievalQA.from_llm(
        llm=llm,
        retriever=retriever,
        prompt=prompt,
        return_source_documents=True,
    )
    logger.info(f"query: {query}")
    
    result:str = ''
    source_documents: list = []
    with time_code_section("Time taken to answer question: "):
        chain_result = qa_chain({"query": query})
        result = chain_result['result']
        source_documents = chain_result['source_documents']
        del store

    tagged_user_questions = set()
    for doc in source_documents[:1]: #not sure if I need to extend it
        question_number = doc.metadata['question_number']
        stage = doc.metadata['stage']
        user_id = doc.metadata['user_id']
        tagged_user_questions.add((user_id, question_number, stage))
    
    # source documents
    media_set = set()
    for user_id, question_number, stage in tagged_user_questions:
        question_media = db.query(
                QuestionAnswerMedia.media_path,
                QuestionAnswerMedia.media_type,
            ).join(
                Question,
                QuestionAnswerMedia.question_id == Question.id
            ).filter(
                Question.question_number == question_number,
                Question.stage_id == stage,
                QuestionAnswerMedia.user_id == user_id,
                QuestionAnswerMedia.media_type.like('image%')
            ).order_by(
                desc(Question.time_created)
            ).limit(4).all()
        
        if not question_media:
            continue
        else:
            for media in question_media:
                media_set.add((
                    media[0], 
                    media[1]
                ))
    
    # log media
    logger.info(
        f'publishing messages - {media_set}'
    )
    
    # publish media
    for media in media_set:
        media_tag = {
            "user_id": user_id,
            "question_number": question_number,
            "stage": stage,
            "query": query,
            "answer": result,
            "media_path": media[0],
            "media_type": media[1],
            "signed_url": generate_signed_url_v4(media[0]),
            "time_created": str(datetime.now()),
        }

        publish_messages(
            attributes={},
            data = json.dumps([media_tag]),
        )


    # log interaction
    interaction_log = ChatInteractions(
            agent_user_id=user_id,
            human_input_text=query,
            bot_output_text=result,
            user_id=user_id,
            chat_type="restful_agent_text",
            chat_metadata={
                "conversation_id":conversation_id,
                "media": str(media_set),
            },
    )
    db.add(interaction_log)
    db.commit()
    db.close()

    return {
        "response": result,
        "type": "restful_agent_text",
    } 

@router.get(
    "/response_api/",
    name="response:get-data",
)
async def get_answers(user_id: str, query: str):
    try:
        store = get_vector_store()
        llm = ChatOpenAI(model_name=RETRIEVAL_MODEL, temperature=TEMPERATURE, openai_api_key="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")
        retriever = store.as_retriever(search_kwargs={'filter': {'user_id': user_id}, 'k': 10})
        prompt = PromptTemplate(template=USER_INSTRUCTIONS, input_variables=['context'], partial_variables={'query': query})
        qa_chain = RetrievalQA.from_llm(llm=llm, retriever=retriever, prompt=prompt)

        logger.info(f"query: {query}")
        result = ''
        with time_code_section("Time taken to answer question: "):
            chain_result = qa_chain({"query": query})
            result = chain_result['result']

        return JSONResponse(content={"result": result})
    except Exception as e:
        logger.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="An error occurred while processing the request")

@router.post(
    "/generate_audio/{user_id}/",
    name="general:generate-audio",
)
async def generate_audio_from_text(
    user_id: str=Path(..., example = 'fd69a44d-d0e9-45f9-a948-30c270e7bacc'),
    data: dict=Body(..., example = {"text": "hello world"}),
):
    text = data.get("text")
    if not text:
        return Response("Missing 'text' field in JSON data", status_code=400)
    
    mp3_audio_binary = generate_audio(
        text,
        user_id
    )

    return Response(
        content=mp3_audio_binary,  # Get the binary WebM data
        media_type="audio/mpeg",
        headers={
            "Content-Disposition": "inline" 
        },
    )


@router.get(
        "/question/",
        name="question:get-data",
        )
async def read_items(
        stage: int | None = None,
        question_number : int | None = None,
        db: Session = Depends(create_database_session)
    ):
    questions = db.query(Question).join(QuestionStage, Question.stage_id == QuestionStage.id)
    items = []
    stage_questions = None
    result = {}
    logger.debug(f"stage: {stage}, question_number: {question_number}")

    stage_is_int = type(stage) is int and stage >= 0
    question_number_is_int = type(question_number) is int and question_number >= 0

    if stage_is_int and question_number_is_int:
        stage_questions = questions.filter(Question.stage_id == stage)
        items = [stage_questions.filter(Question.question_number == question_number).order_by(
            desc(Question.time_created)).first()]
        stage_name = stage_questions.with_entities(QuestionStage.stage_name).first()
        if stage_name is not None:
            result['stage_information'] = {
                "stage_name": stage_name[0],
                "total_stage_questions":stage_questions.count()
            }
        items = items
    elif stage_is_int and not question_number_is_int:
        stage_questions = questions.filter(Question.stage_id == stage)
        items = stage_questions.order_by(
            Question.question_number
        ).all()
        stage_name = stage_questions.with_entities(
            QuestionStage.stage_name
        ).first()
        if stage_name is not None:
            result['stage_information'] = {
                "stage_name": stage_name[0],
                "total_stage_questions":stage_questions.count()
            }
    elif stage is None and question_number is None:
        items = questions.order_by(
            Question.question_number
        ).all()
    else:
        raise HTTPException(
            status_code=400, 
            detail="Invalid stage or question number"
        )

    result['questions'] = jsonable_encoder(items)
    response_object = JSONResponse(
        content=result,  
        media_type="application/json",
        headers={
            "Cache-Control": "public, max-age=3600, s-maxage=3600"
        },
    )
    return response_object

@router.post("/upload/{question_stamp}/", name="answer:upload")
async def upload_file(
    file: UploadFile=File(...),
    question_stamp: str=Path(...),
    db: Session=Depends(create_database_session),
    user_id: str=DEFAULT_USER_ID,
):

    stage, question_number = extract_stage_and_question_number(question_stamp)

    try:
        #get question id from question_number and stage
        question_id = db.query(Question).order_by(desc(Question.time_created)).filter(
            Question.question_number == question_number, Question.stage_id == stage
        ).first().id

        logger.debug(question_id)


        url = upload_file_to_gcp_storage(
            file,
            GCS_FILES_BUCKET_NAME,
            f'{user_id}/{stage:02d}/{question_number:03d}/'
        )

        answer_media = QuestionAnswerMedia(
            question_id=question_id,
            media_path=url,
            media_type=file.content_type,
            user_id=user_id,
        )
        db.add(answer_media)
        db.commit()
        db.close()

        logger.info(
            f"URL: {url} \n"
            f"Filename: {file.filename} \n"
            f"Question ID: {question_id} \n"
            f"Answer Uploaded"
        )

        return {"filename": file.filename, "url": url}
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=500, detail="An error occurred during upload.") 

@router.post("/uploads/{question_stamp}/", name="answer:uploads")
async def upload_files(
    files: List[UploadFile]=File(...),
    question_stamp: str=Path(...),
    db: Session=Depends(create_database_session),
    user_id: str=DEFAULT_USER_ID,
):

    stage, question_number = extract_stage_and_question_number(question_stamp)

    try:
        # get question id from question_number and stage
        question_id = db.query(Question).order_by(desc(Question.time_created)).filter(
            Question.question_number == question_number, Question.stage_id == stage
        ).first().id

        results = []  # Store results for all uploaded files

        for file in files:
            url = upload_file_to_gcp_storage(
                file,
                GCS_FILES_BUCKET_NAME,
                f'{user_id}/{stage:02d}/{question_number:03d}/'
            )

            answer_media = QuestionAnswerMedia(
                question_id=question_id,
                media_path=url,
                media_type=file.content_type,
                user_id=user_id,
            )
            db.add(answer_media)
            db.commit()
            db.close()

            logger.info(
                f"URL: {url} \n"
                f"Filename: {file.filename} \n"
                f"Question ID: {question_id} \n"
                f"Answer Uploaded"
            )

            results.append({"filename": file.filename, "url": url})

        return results 

    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=500, detail="An error occurred during upload.") 




#write a new path to get user progress using get_user_progress_statement
@router.get("/user_progress/questions/", name="answer:user_progress")
async def get_user_progress(
    db: Session = Depends(create_database_session),
    user_id: str = DEFAULT_USER_ID,
    stage: int = 0,
    question_number: int = 0,
):
    statement = get_user_progress_statement(
        user_id, stage, question_number
    )

    statement_execution = db.execute(statement)
    result_object = statement_execution.fetchall()

    result_columns = statement.columns.keys()
    logger.debug(result_columns)

    logger.debug(result_columns)
    results = [
        dict(zip(result_columns,result)) for result in result_object
    ]

    logger.debug(results[:1])
    db.close()
    return {"results": results}


#write a new path to get user progress using get_user_progress_statement
@router.get("/user_progress/stages/", name="answer:user_progress_stages")
async def get_user_stage_progress(
    db: Session = Depends(create_database_session),
    user_id: str = DEFAULT_USER_ID,
    stage: int = 0,
):
    statement = get_user_stage_progress_statement(
        user_id, stage
    )

    statement_execution = db.execute(statement)
    result_object = statement_execution.fetchall()
    logger.debug(result_object)

    result_columns = statement.columns.keys()
    logger.debug(result_columns)

    logger.debug(result_columns)
    results = [
        dict(zip(result_columns,result)) for result in result_object
    ]
    db.close()
    logger.debug(results[:1])
    return {"results": results}

@router.get("/pull_media_messages/", name="answer:pull_media_messages")
async def pull_media_messages(
    user_id: str = DEFAULT_USER_ID,
    db: Session = Depends(create_database_session),
):
    user_messages = []
    to_ack = []
    go_ahead = False
    empty_results = []

    
    
    #write code to query ChatInteraction table for messages from user id in the last 2 minutes
    check_db_to_see_if_messages_exist = db.query(ChatInteractions).filter(
        ChatInteractions.time_created > datetime.now() - timedelta(minutes=2)
    ).filter(
        text(f"user_id='{user_id}' AND chat_metadata->>'media' IS NOT NULL")
    ).all()


    logger.info(f"check_db_to_see_if_messages_exist: {check_db_to_see_if_messages_exist}")

    if not check_db_to_see_if_messages_exist:
        return empty_results

    messages = pull_messages()
    llm = OpenAI(
        model_name=RETRIEVAL_MODEL,
        temperature=1,
    )

    for message_dict in messages:
        message = message_dict['message']
        ack_id = message_dict['ack_id']
        logger.info(f"{message['user_id']} - {message}")
        if message["user_id"] == user_id:
            user_messages.append(message)
            to_ack.append(ack_id)
        
            question = message['query']
            answer = message['answer']
            prompt_text = (
                f"Only answer with yes or no. "
                f"This is the question  '{question}' does the text '{answer}' answer it?"
            )
            prompt = llm.invoke(prompt_text)
            logger.info(f"Prompt: {prompt_text} - Response: {prompt}")
            if 'yes' in prompt.lower():
                go_ahead = go_ahead or True
    

    #acknowledge messages even when the answer is worthless so we clean the queue
    for ack in to_ack: ack_message(ack)
    
    # only return messages if the answer is worth it
    if go_ahead:
        logger.info('going ahead')
        result_messages = list(user_messages)
    else:
        result_messages = empty_results
    
    logger.info(user_messages)
    return result_messages