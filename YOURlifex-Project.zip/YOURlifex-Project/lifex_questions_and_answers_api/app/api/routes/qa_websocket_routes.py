
import asyncio
from datetime import datetime
import io


from pydub import AudioSegment
# from firebase_admin import auth
# from firebase_admin.exceptions import FirebaseError

from fastapi import APIRouter, Depends, Path
from fastapi.websockets import WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session
from sqlalchemy import desc

from core.config import DEFAULT_USER_ID, extract_stage_and_question_number, logger, DEBUG
from core.config import create_database_session
from core.events import get_connection_manager, get_timer
from services.speech_to_text import get_speech_to_text, SpeechToText
from models.questions_answers_model import QuestionAnswer, Question


router = APIRouter()

manager = get_connection_manager()

timer = get_timer()

# TODO: ADD AUTHORISATIONS
# TODO: ADD a service account for cloud run
# TODO: MAKE ANSWER SLOWLY CHANGING DIMENSION MODEL


# TODO: ADD NEW DATA MODELS LIKE INTERACTIONS AND UPDATE QUESTIONS ANSWERS MODEL + ALSO LOG METADATA INTO GCS FILES in a table (DONE)
# TODO: EDIT METADATA IN GCS FILES (DONE)


# TODO: ADD A ROUTE FOR PROGRESS BAR AND LET IT KNOW IF THE QUESTION IS ANSWERED
# TODO: Add tmp user in all environments




@router.websocket("/ws/record_to_file/{file_name}")
async def websocket_record_to_file_endpoint(
    websocket: WebSocket,
    speech_to_text=Depends(get_speech_to_text),
    file_name: str = Path(...),
    db: Session = Depends(create_database_session),
    user_id: str = DEFAULT_USER_ID,
):

    await manager.connect(websocket)


    stage, question_number = extract_stage_and_question_number(
        file_name=file_name
    )

    if stage is None and question_number is None:
        msg = "format should be s#q#: example s1q1 for stage 1 question 1"
        await manager.disconnect(websocket)
        await manager.broadcast_message(msg)
        logger.info(msg)
        return

    try:
        logger.info("Websocket Connected")
        record_task = asyncio.create_task(
            handle_record_to_file(
                websocket=websocket, speech_to_text=speech_to_text, 
                file_name=f's{stage:02d}q{question_number:03d}',
                db=db,
                question_number=question_number,
                stage=stage, user_id=user_id
            )
        )

        await asyncio.gather(record_task)
        logger.info("Voice Record Upload Completed")


    except WebSocketDisconnect:
        await manager.disconnect(websocket)
        await manager.broadcast_message(f"Voice recorded and user left")
        logger.info("Websocket Disconnected")

def convert_audio_bytes_list_to_file(
        audio_bytes_list : list, filename: str="output.webm", 
        user_id: str="", start_time : datetime = datetime.now(), 
        single_file: bool=False, file_number: int=0
    ):
    """
    Converts a list of audio bytes into a single WEBM file.

    Args:
        audio_bytes_list (list): A list of audio data chunks (each chunk as bytes).
        filename (str, optional): The desired filename for the output WAV file.
                                  Defaults to "output.wav".
    """
    from services.gcp_jobs import export_audio_to_gcs_in_memory, DEFAULT_AUDIO_BUCKET, DEFAULT_USER_FOLDER

    gcs_destinations = []
    now = start_time
    formatted_datetime = now.strftime("%Y%m%d_%H%M%S_%f")

    if single_file is False:
        for i,audio_bytes in enumerate(audio_bytes_list):
            # Get the current date and time
            
            webm_audio = AudioSegment.from_file(io.BytesIO(audio_bytes), format="webm")

            user_folder = user_id or DEFAULT_USER_FOLDER
            object_name = f'{formatted_datetime}-{filename}-{i}.mp3'

            # Get the duration in seconds
            audio_length_ms = len(webm_audio)
            
            gcs_destination = export_audio_to_gcs_in_memory(
                    webm_audio, 
                    DEFAULT_AUDIO_BUCKET, 
                    f'{user_folder}/{object_name}'
                )

            gcs_destinations.append(
                (gcs_destination, audio_length_ms)
            )
    else:
        audio_bytes = audio_bytes_list[0]
        webm_audio = AudioSegment.from_file(io.BytesIO(audio_bytes), format="webm")

        user_folder = user_id or DEFAULT_USER_FOLDER
        object_name = f'{formatted_datetime}-{filename}-{file_number}.mp3'

        # Get the duration in seconds
        audio_length_ms = len(webm_audio)
        
        gcs_destination = export_audio_to_gcs_in_memory(
                webm_audio, 
                DEFAULT_AUDIO_BUCKET, 
                f'{user_folder}/{object_name}'
            )

        gcs_destinations.append(
            (gcs_destination, audio_length_ms)
        )
    
    return gcs_destinations


async def handle_record_to_file(
        websocket: WebSocket,
        speech_to_text: SpeechToText,
        file_name: str = Path(...),
        db: Session = next(
            create_database_session()
        ),
        question_number: int|None = None,
        stage: int|None = None,
        user_id: str = DEFAULT_USER_ID
        ):
    
    try:
        audio_binary_data = []
        session_time_stamp = datetime.now()
        while True:
                data = await websocket.receive()

                # handle disconnect
                if data['type'] != 'websocket.receive':
                    logger.info("Line 164 is disconnecting... -_-")
                    raise WebSocketDisconnect(reason='disconnected')

                # handle text message
                if 'text' in data:
                    text = data['text']
                    logger.info(f"Text: {text}")
                    await manager.send_message(message=text+' '+'hahaha', websocket=websocket)

                # handle binary message(audio)
                if 'bytes' in data:
                    binary_data = data['bytes']

                    if DEBUG:
                        # 1. Transcribe audio
                        transcript: str = (await asyncio.to_thread(speech_to_text.transcribe,
                            binary_data)).strip()
                        logger.info(f"Transcript: {transcript}")

                        # 2. Send transcript
                        await manager.send_message(message='transcript_manager '+transcript, websocket=websocket)
                        
                        # ignore audio that picks up background noise
                        if (not transcript or len(transcript) < 2):
                            logger.info("Skipping")
                            continue

                    # 3. Append audio and log audio length
                    audio_binary_data.append(binary_data)
                    await manager.send_message(
                        message=f'processing audio_segment no. {len(audio_binary_data)}', 
                        websocket=websocket
                    )

                    try:
                        # 4. Upload audio to GCS
                        uploaded_file_path, audio_length = convert_audio_bytes_list_to_file(
                            filename=f"{file_name}", audio_bytes_list=[binary_data], 
                            start_time=session_time_stamp, user_id=user_id,
                            single_file=True, file_number=len(audio_binary_data),
                        )[0]

                        #Get the latest question that carries the question number and stage
                        question_id = db.query(Question).filter(
                            Question.question_number == question_number
                            ).filter(
                            Question.stage_id == stage
                            ).order_by(
                                desc(Question.time_created)
                            ).first().id
                        
                        # 5. Add audio data to the question_answers table
                        new_answer = QuestionAnswer(
                            user_id=user_id, #todo: get user id one auth is done
                            question_id=question_id, 
                            answer_voice_record_path=uploaded_file_path,
                            answer_voice_record_length_ms=audio_length,
                        )
                        db.add(new_answer)
                        db.commit()
                        db.close()

                        logger.info(f"Uploaded file path: {uploaded_file_path}")
                        await manager.send_message(f"audio {len(audio_binary_data)} uploaded Sucessfully!", websocket=websocket)
                        await manager.send_message(f"path: {uploaded_file_path}", websocket=websocket)

                    except Exception as e:
                        logger.error(e) 
                        await manager.send_message(f"Internal Server Error - {e}", websocket=websocket)

                    # log latency info
                    timer.report()
                
    except WebSocketDisconnect:
        logger.info(f"User closed the connection")
        timer.reset()

        await manager.disconnect(websocket)
        return
