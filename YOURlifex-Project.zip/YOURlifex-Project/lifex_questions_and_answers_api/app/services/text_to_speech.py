from typing import Iterator
from elevenlabs.client import ElevenLabs
from sqlalchemy.orm import Session


from core.config import (
    get_engine,
    logger,
    config,
)
from models.questions_answers_model import User

ELEVENLABS_API_KEY = config("ELEVENLABS_API_KEY", default="")



def get_user_voice_id(user_id):
    with Session(get_engine()) as session:
        user_rows = session.query(User).filter(User.id == user_id).with_entities(User.voice_id)

        voice_id:str|None = None

        try:
            if user_rows.first():
                voice_id= user_rows.all()[0][0]
                logger.info("User voice id found in DB:")
                logger.info(voice_id)

            client = ElevenLabs(
                api_key=ELEVENLABS_API_KEY,
            )
            response = client.voices.get_all()
            voices : list = [voice.voice_id for voice in response.voices]
            voice_exists = voice_id in voices
            logger.info(
                f"Voice exists in elevenlabs state {voice_exists}: {voice_id}"
            )
            if not voice_exists:
                raise Exception(f"Voice {voice_id} does not exist")
        except Exception as e:
            logger.info(e)
            logger.info("User not found.")

        if not voice_id:
            logger.info("Using the default voice id")
            voice_id = config("ELEVENLABS_VOICE_ID")
        
        logger.info("User voice id:")
        logger.info(voice_id)
        return voice_id

def generate_audio(
        text: str,
        user_id: str,
    ):

    voice_id = get_user_voice_id(
        user_id,
        )
    client = ElevenLabs(
        api_key=ELEVENLABS_API_KEY,
    )

    audio_result = client.generate(
            text=text,
            voice=voice_id,
            stream = False,
            model = "eleven_turbo_v2",
        )
    
    mp3_audio_binary : bytes
    
    if isinstance(audio_result, Iterator):
        audio_result = b"".join(audio_result)
        mp3_audio_binary = audio_result
        return mp3_audio_binary

    elif type(audio_result) == bytes:
        mp3_audio_binary = audio_result
        return mp3_audio_binary

    else:
        logger.error(audio_result)
        raise Exception("Eleven Labs API Error cannot generate audio.")