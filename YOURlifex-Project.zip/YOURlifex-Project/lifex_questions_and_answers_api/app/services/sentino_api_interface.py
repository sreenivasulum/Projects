import requests
import json
from base64 import b64decode

from core.config import (
    SENTINO_API_KEY,
    logger
)

def assess_personality_traits(items_to_assess: list[dict]):
    url = "https://api.sentino.org/api/score/items"

    # items_to_assess : list[dict] = [
    #     {
    #     "item": "I like to go out and I am an extrovert on the big 5 scale. I am lively and outgoing person with a great enthusiasm for life. People are drawn to my sociable nature, and I often take charge in social situations with confidence. I am  an excellent communicator and storyteller, captivating others with my tales. my positive and charismatic personality inspires those around my to embrace life wholeheartedly. In any group, I am the one spreading happiness and being the life of the party",
    #     "response": "strongly agree"
    #     },
    #     {
    #     "item": "I am adaptable and very agreeable.",
    #     "response": "agree"
    #     }
    # ]

    payload = json.dumps({
    "inventories": [
        "big5"
    ],
    "items": items_to_assess,
    "provide_texts": True
    })

    headers = {
    'Authorization': b64decode(SENTINO_API_KEY).decode('utf-8'),
    'Content-Type': 'application/json'
    }

    logger.info(
        f'Sending POST request to Sentino API... {payload}'
    )

    # Send POST request
    response = requests.request("POST", url, headers=headers, data=payload)

    full_json_response = response.json()

    scoring_json = full_json_response['scoring']

    return scoring_json


def scoring_json_to_text(json_data):
    """Converts a nested JSON structure with personality traits into readable text.

    json_data_example = '''
        {
        "big5": {
                    "agreeableness": {
                        "quantile": 0.678,
                        "score": 0.91,
                        "confidence": 0.129,
                        "confidence_text": "low",
                        "texts": {
                            "general": "Agreeableness measures an individual's level of compassion, cooperativeness, and empathy.",
                            "quantile-specific": "If you're highly agreeable, you bring a unique mix of qualities that make you indispensable in social situations. Your warmth, compassion, and ability to nurture positive relationships really stand out. You're empathetic and naturally understanding, providing crucial support for those in need. Your willingness to find compromises and work toward solutions shows your skill in problem-solving. Plus, your ability to navigate social situations with finesse and poise inspires loyalty and trust, making you a valuable team member and a leader worth following. In tough times, your forgiving and empathetic nature plays a key role in maintaining harmony and peace in your social circles."
                        }
                    },
                    "conscientiousness": {
                        "quantile": 0.619,
                        "score": 0.622,
                        "confidence": 0.062,
                        "confidence_text": "low",
                        "texts": {
                            "general": "Conscientiousness measures an individual's level of organization, responsibility, and dependability.",
                            "quantile-specific": "You, with high conscientiousness, are greatly appreciated for your strong work ethic, disciplined approach, and sense of responsibility. Your determination to succeed in all aspects of life is clear, and people recognize your careful and thorough way of handling tasks. Your focus on details and ability to plan ahead help you avoid problems and reach your goals smoothly. Others see you as reliable, trustworthy, and an excellent team member who consistently produces high-quality work. Your commitment to excellence is the foundation of your achievements, making you a role model for your steadfastness and dedication."
                        }
                    },
                    "extraversion": {
                        "quantile": 0.873,
                        "score": 0.982,
                        "confidence": 0.635,
                        "confidence_text": "high",
                        "texts": {
                            "general": "Extraversion assesses an individual's level of sociability, assertiveness, talkativeness, and overall preference for social stimulation.",
                            "quantile-specific": "You're a lively and outgoing person with a great enthusiasm for life. People are drawn to your sociable nature, and you often take charge in social situations with confidence. You're an excellent communicator and storyteller, captivating others with your tales. Your positive and charismatic personality inspires those around you to embrace life wholeheartedly. In any group, you're the one spreading happiness and being the life of the party."
                        }
                    },
                    "neuroticism": {
                        "quantile": 0.249,
                        "score": -0.887,
                        "confidence": 0.26,
                        "confidence_text": "normal",
                        "texts": {
                            "general": "Neuroticism assesses an individual's emotional stability, anxiety levels, and sensitivity to stress.",
                            "quantile-specific": "Your emotional stability is truly remarkable, enabling you to navigate life's complexities with remarkable grace. Your calm and collected attitude, even when faced with tough situations, inspires others. You're like a strong support system, guiding us through challenges with confidence and a peaceful demeanor. Your ability to stay steady in tough times shows how resilient and self-assured you are, which is valued in both personal and professional situations. Your emotional balance and grace are the key features of a fulfilling life, filled with purpose and satisfaction."
                        }
                    },
                    "openness": {
                        "quantile": 0.745,
                        "score": 0.996,
                        "confidence": 0.193,
                        "confidence_text": "low",
                        "texts": {
                            "general": "Openness refers to an individual's imagination, creativity, and willingness to experience new things.",
                            "quantile-specific": "As an individual with a high score in openness, you are curious and imaginative, always eager to explore new ideas, cultures, and experiences. You have a deep passion for understanding the world, constantly seeking fresh insights and making connections. Your ability to think creatively allows you to tackle challenges in unique ways, coming up with innovative solutions. You often express your appreciation for aesthetics and beauty through art forms like music, literature, or painting. Your open-mindedness and intellectual flexibility make you a valuable asset to any team, bringing in new perspectives and ideas that challenge the usual norms."
                        }
                    }
                }
        }
    '''
    """
    text = ""
    logger.info("Processing Sentino Results...")
    for trait, data in json_data['big5'].items():  # Iterate through traits (e.g., "agreeableness")
        logger.info(f"Trait: {trait}")
        logger.info(f"Data: {data}")
        text += f"\n**{trait.capitalize()}**\n"
        text += f"{data['texts']['general']}\n"
        text += f"{data['texts']['quantile-specific']}\n"
    return text
