import io
import wave
from abc import ABC, abstractmethod

import speech_recognition as sr
from pydub import AudioSegment

from core.config import logger
from core.events import Singleton, timed

DEBUG = False


class SpeechToText(ABC):
    @abstractmethod
    @timed
    def transcribe(
        self, audio_bytes
    ) -> str:
        pass


class Whisper(Singleton, SpeechToText):
    def __init__(self):
        super().__init__()

        self.recognizer = sr.Recognizer()
        if DEBUG:
            self.wf = wave.open("output.wav", "wb")
            self.wf.setnchannels(1)  # Assuming mono audio
            self.wf.setsampwidth(2)  # Assuming 16-bit audio
            self.wf.setframerate(44100)  # Assuming 44100Hz sample rate

    @timed
    def transcribe(self, audio_bytes) -> str:
        logger.info("Transcribing audio...")
        audio = self._convert_webm_to_wav(audio_bytes)
        return self._transcribe_api(audio)

    def _transcribe_api(self, audio):
        #better set the openai api key via environment variables
        text = self.recognizer.recognize_whisper_api(
            audio,
        )
        return text

    def _convert_webm_to_wav(self, webm_data):
        webm_audio = AudioSegment.from_file(io.BytesIO(webm_data), format="webm")
        wav_data = io.BytesIO()
        webm_audio.export(wav_data, format="wav")
        with sr.AudioFile(wav_data) as source:
            audio = self.recognizer.record(source)
        return audio

    def _convert_bytes_to_wav(self, audio_bytes):
        return sr.AudioData(audio_bytes, 44100, 2)
    
    def transcribe_file(self, audio_file):
        audio = self._convert_webm_file_to_wav(audio_file)
        return self._transcribe_api(audio)

    def _convert_webm_file_to_wav(self, webm_file):
        webm_audio = AudioSegment.from_file(webm_file, format="webm")
        wav_data = io.BytesIO()
        webm_audio.export(wav_data, format="wav")
        with sr.AudioFile(wav_data) as source:
            audio = self.recognizer.record(source)
        return audio
    

def get_speech_to_text():
    Whisper.initialize()
    return Whisper.get_instance()
