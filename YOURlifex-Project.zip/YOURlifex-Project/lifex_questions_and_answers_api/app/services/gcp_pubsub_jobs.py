from ast import Tuple
from datetime import datetime
import time
import json
from concurrent import futures
from google.cloud import pubsub_v1
from typing import Callable

from core.logging import logger
from core.config import (
    GCP_PROJECT_ID,
    PUBSUB_TOPIC,
    PUBSUB_SUBSCRIPTION
)

def publish_messages(
        attributes: dict = {},
        project_id: str = GCP_PROJECT_ID,
        topic_id: str = PUBSUB_TOPIC,
        data: str = "hello",
    ) -> bool:
    """
    Publishes messages to a Pub/Sub topic.

    Args:
        attributes (dict, optional): Additional attributes to include with the message. Defaults to an empty dictionary.
        project_id (str, optional): The ID of the Google Cloud project. Defaults to the value of the GCP_PROJECT_ID environment variable.
        topic_id (str, optional): The ID of the Pub/Sub topic. Defaults to the value of the PUBSUB_TOPIC environment variable.
        data (str, optional): The message data. Defaults to "hello".

    Returns:
        bool: True if the messages were successfully published, False otherwise.

    Raises:
        TimeoutError: If the publish call takes longer than 60 seconds to succeed.

    """

    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)

    def get_callback(
        publish_future: pubsub_v1.publisher.futures.Future, data: str
    ) -> Callable[[pubsub_v1.publisher.futures.Future], None]:
        def callback(publish_future: pubsub_v1.publisher.futures.Future) -> None:
            try:
                # Wait 60 seconds for the publish call to succeed.
                logger.info(publish_future.result(timeout=60))
            except futures.TimeoutError:
                logger.error(f"Publishing {data} timed out.")
                raise TimeoutError("Publishing timed out.")

        return callback

    # When you publish a message, the client returns a future.
    publish_future = publisher.publish(
        topic_path, 
        data.encode("utf-8"),
        **attributes
    )
    publish_future.add_done_callback(
        get_callback(publish_future, data)
    )

    # Wait for all the publish futures to resolve before exiting.
    futures.wait([publish_future], return_when=futures.ALL_COMPLETED)

    logger.info(f"Published messages with error handler to {topic_path}.")

    return True


def pull_messages(
        project_id: str = GCP_PROJECT_ID,
        subscription_id: str = PUBSUB_SUBSCRIPTION,
        max_messages: int = 10,
    ) -> list[dict]:
    """
    Pulls messages from a Google Cloud Pub/Sub subscription.

    Args:
        project_id (str): The ID of the Google Cloud project. Defaults to GCP_PROJECT_ID.
        subscription_id (str): The ID of the Pub/Sub subscription. Defaults to PUBSUB_SUBSCRIPTION.
        max_messages (int): The maximum number of messages to pull. Defaults to 10.

    Returns:
        list: A list of received messages. Each message is a dictionary containing the message data.

    Raises:
        Exception: If there is an error pulling messages from the subscription.

    Processes each received message by decoding the message data and appending it to the messages list.
    Invalid JSON messages are logged as errors and skipped.
    After processing all messages, the function acknowledges the received messages by sending an acknowledgement request to the Pub/Sub subscription.
    """
    subscription_id = PUBSUB_SUBSCRIPTION
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(
        project_id,
        subscription_id,
    )
    messages = []

    with subscriber:

        # Pull messages
        try:
            response = subscriber.pull(
                request={
                    "subscription": subscription_path,
                    "max_messages": max_messages
                },
                timeout=5,
            )
        except Exception as e:
            logger.error(e)
            return []
        
        for msg in response.received_messages:
            message_data_str : str = msg.message.data.decode("utf-8")
            logger.info(f"Received message: {message_data_str}")

            # Process the message...
            if message_data_str:
                try:
                    if type(message_data_str) == str: 
                        message_data : list = json.loads(message_data_str)
                except json.decoder.JSONDecodeError:
                    logger.error(f"Invalid JSON: {message_data}")
                    continue
                
                messages.append(message_data)

        # Acknowledge received messages
        ack_ids = [msg.ack_id for msg in response.received_messages]
        
        output_messages = []
        for ack_id, message in zip(ack_ids, messages):
            output_messages.append({
                "ack_id": ack_id,
                "message": message[0] if type(message) == list else message,
            })

        logger.info(f'Output messages: {output_messages} - {type(output_messages)}')
        return output_messages


def ack_message(
        ack_id: str,
        project_id: str = GCP_PROJECT_ID,
        subscription_id: str = PUBSUB_SUBSCRIPTION
        ) -> None:
    """
    Acknowledges a single Pub/Sub message.

    Args:
        ack_id (str): The acknowledgment ID of the message to acknowledge.
        project_id (str, optional): The ID of the Google Cloud project. Defaults to GCP_PROJECT_ID.
        subscription_id (str, optional): The ID of the Pub/Sub subscription. Defaults to PUBSUB_SUBSCRIPTION.
    """
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, subscription_id)

    logger.info(f"Acknowledging message with ack_id: {ack_id}")
    subscriber.acknowledge(
        request={"subscription": subscription_path, "ack_ids": [ack_id]}
    )

if '__main__' == __name__:
    # publish_messages(
    #     attributes={'user_id':'2','question_number':'1', 'stage':'0', 'query':'test query', 'answer':'test'}, 
    #     data = json.dumps([{"media_type":"jpg","media_path":"test.jpg", "signed_url": "test"}]),
    # )
    # time.sleep(3)
    a = pull_messages()
    # ack_message(a['ack_ids'][0])
    print(a)