import datetime
import base64
import json
import re

from fastapi import HTTPException
from google.cloud import storage

from core.logging import logger
from core.config import (
    DEFAULT_USER_ID,
    GCS_FILES_BUCKET_NAME,
    DEFAULT_AUDIO_BUCKET,
    GCS_SERVICE_ACCOUNT_KEY,
)

DEFAULT_USER_FOLDER = DEFAULT_USER_ID
DEFAULT_GCS_OBJECT = f'{DEFAULT_USER_FOLDER}/tmp.mp3'

def copy_file_to_gcp_bucket(
        file_path,
        bucket_name=DEFAULT_AUDIO_BUCKET,
        full_gcs_object_name=DEFAULT_GCS_OBJECT,
        metadata={},
        ):
    """Copy a file to a folder in a Google Cloud Storage bucket assuming gcloud credentials are already set up.

    Args:
        file_path (str): Path to the file to be copied.
        bucket_name (str): Name of the Google Cloud Storage bucket.
        folder_name (str): Name of the folder in the bucket to copy the file into.
    """
    from google.cloud import storage

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(full_gcs_object_name)
    blob.metadata = metadata
    blob.upload_from_filename(file_path)

    return f'gs://{bucket_name}/{full_gcs_object_name}'

def upload_file_to_gcp_storage(
        file,
        bucket_name: str=GCS_FILES_BUCKET_NAME,
        prefix: str= DEFAULT_USER_ID,
    ) -> str:
    """
        Uploads a file to a Google Cloud Storage bucket.

        Args:
            file: The file to be uploaded.
            bucket_name: The name of the Google Cloud Storage bucket.

        Returns:
            str: The public URL of the uploaded file.
    """
    
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket_name)

    blob = bucket.blob(prefix+file.filename)
    blob.upload_from_file(
        file.file,
        content_type=file.content_type,
    )
    
    return f"gs://{bucket_name}/{prefix}{file.filename}"

def export_audio_to_gcs_in_memory(audio_segment, bucket_name, full_gcs_object_name=DEFAULT_GCS_OBJECT):
    """Exports an AudioSegment to a GCS bucket directly from memory."""
    import tempfile

    uploaded_file_path: str | None = None
    with tempfile.NamedTemporaryFile() as temp_file:
        audio_segment.export(temp_file.name, format="mp3")
        metadata = {
            "Content-Type": "audio/mpeg",
        }
        uploaded_file_path = copy_file_to_gcp_bucket(
            temp_file.name, 
            bucket_name, 
            full_gcs_object_name,
            metadata
        )
    return uploaded_file_path

def download_gcs_file_as_bytes(bucket_name, blob_name):

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    # Download audio file data into memory
    image_byte_data = blob.download_as_bytes()

    return image_byte_data

def generate_signed_url_v4(image_path):
    """Generates a v4 signed URL for downloading a blob."""

    image_path_parts = re.search(r"^gs://([^/]+)/(.*)", image_path)

    if not image_path_parts:
        logger.warning(f'Bad file format: {image_path}')
        raise HTTPException(status_code=404, detail="Profile picture not found")
    bucket_name, blob_name = image_path_parts.groups()

    
    key_json= json.loads(
        base64.b64decode(GCS_SERVICE_ACCOUNT_KEY)
    )
    storage_client = storage.Client.from_service_account_info(key_json)
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    url = blob.generate_signed_url(
        version="v4",
        expiration=datetime.timedelta(minutes=15),
        method="GET",
    )

    logger.info(f"Generated GET signed URL: {url}")
    return url