from pydantic import Json
from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    Integer,
    String,
    func,
)
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import ForeignKey
from sqlalchemy import DateTime
import uuid
from sqlalchemy.dialects.postgresql import UUID

Base = declarative_base()

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True)
    time_created = Column(DateTime, server_default=func.now())
    user_name = Column(String)
    voice_id = Column(String)

class PersonalityAssessments(Base):
    __tablename__ = "personality_assessments"

    id = Column(String, primary_key=True, default=uuid.uuid4)
    user_id = Column(String, ForeignKey('users.id'))
    time_created = Column(DateTime, server_default=func.now())
    test_type = Column(String)
    assessment_result_summary = Column(String)
    assessment_result_raw = Column(String)

class QuestionStage(Base):
    __tablename__ = "question_stages"

    id = Column(Integer, primary_key=True)
    stage_name = Column(String, unique=True)
    time_created = Column(DateTime, server_default=func.now())

class Question(Base):
    __tablename__ = "questions"

    id = Column(Integer, primary_key=True)
    time_created = Column(DateTime, server_default=func.now())
    question_number = Column(Integer)
    question = Column(String, unique=True)
    stage_id = Column(Integer, ForeignKey('question_stages.id'))
    stage = relationship("QuestionStage")

class QuestionAnswer(Base):
    __tablename__ = "question_answers"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    time_created = Column(DateTime, server_default=func.now())
    answer_text = Column(String)
    answer_voice_record_path = Column(String)
    answer_voice_record_length_ms = Column(Integer)
    question_id = Column(Integer, ForeignKey('questions.id'))
    user_id = Column(String, ForeignKey('users.id'))
    in_vector_db = Column(Boolean, default=False)

class QuestionAnswerMedia(Base):
    __tablename__ = "question_media"

    id = Column(Integer, primary_key=True)
    time_created = Column(DateTime, server_default=func.now())
    media_path = Column(String)
    media_type = Column(String)
    user_id = Column(String, ForeignKey('users.id'))
    question_id = Column(Integer, ForeignKey('questions.id'))
    question = relationship("Question")
    in_vector_db = Column(Boolean, default=False)

class ChatInteractions(Base):
    __tablename__ = "chat_interactions"

    id =  Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    time_created = Column(DateTime, server_default=func.now())
    agent_user_id = Column(String)
    human_input_text = Column(String)
    bot_output_text = Column(String)
    chat_type = Column(String)
    chat_metadata = Column(JSON)
    user_id = Column(String)