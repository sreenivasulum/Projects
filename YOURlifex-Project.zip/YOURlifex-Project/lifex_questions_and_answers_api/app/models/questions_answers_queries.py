from core.config import DEFAULT_USER_ID
from sqlalchemy import case, func, select
from models.questions_answers_model import Question, QuestionAnswer




def get_user_progress_statement(
        user_id=DEFAULT_USER_ID,
        stage:int|None=0,
        question_number:int|None=0
    ):
    
    # answers subquery to limit answers to user
    answers_subquery = (
        select(QuestionAnswer) 
        .where(QuestionAnswer.user_id == user_id)
    ).subquery('answers') 


    # questions subquery to limit questions to stage
    base_questions_subquery =(
            select(Question) 
        )
    
    if stage is not None and question_number is not None:
        questions_subquery_step_1 = base_questions_subquery.filter(Question.stage_id == stage)
        questions_subquery = questions_subquery_step_1.filter(Question.question_number == question_number).subquery('questions')
    elif stage is not None:
        questions_subquery = base_questions_subquery.filter(Question.stage_id == stage).subquery('questions')
    else:
        questions_subquery = base_questions_subquery.subquery('questions')

    main_query = (
        select(
            questions_subquery.c.question_number,
            questions_subquery.c.stage_id,
            questions_subquery.c.question,
            case(
                (func.count(answers_subquery.c.id.distinct()) > 0, "Answered"),  
                else_="Not Answered"
            ).label("question_state"),
            case(
                (func.count(answers_subquery.c.id.distinct()) > 0, ".complete"),  
                else_=".incomplete"
            ).label("class"),
            func.to_char(func.max(answers_subquery.c.time_created), 'YYYY-MM-DD HH24:MI:SS.MS').label("latest_answer"),
            (1.0*func.sum(answers_subquery.c.answer_voice_record_length_ms)/func.count(answers_subquery.c.id.distinct())).label("average_answer_length_ms"),
        )
        .outerjoin(answers_subquery, questions_subquery.c.id == answers_subquery.c.question_id)
        .group_by(
            questions_subquery.c.question, 
            questions_subquery.c.question_number, 
            questions_subquery.c.stage_id
        )
        .order_by(questions_subquery.c.stage_id, questions_subquery.c.question_number) 
    )

    return main_query


def get_user_stage_progress_statement(user_id=DEFAULT_USER_ID, stage:int=0):
    """
    Retrieves the progress statement for a specific user and stage.

    Args:
    user_id (int): The ID of the user (default is DEFAULT_USER_ID)
    stage (int): The stage for which progress is being retrieved

    Returns:
    sqlalchemy.sql.select: The query to retrieve the progress statement
    """
    
    # Get the main query for user progress
    main_query = get_user_progress_statement(
        user_id=user_id,
        stage=stage,
        question_number=None,
    )

    # Define a case for answered questions
    answered_case = case(
        (main_query.c.question_state == "Answered", main_query.c.question_number),
        else_=None
    )

    # Define a case for not answered questions
    not_answered_case = case(
        (main_query.c.question_state == "Not Answered", main_query.c.question_number),
        else_=None
    )
    
    # Create the result query
    result_query = select(
        main_query.c.stage_id,
        func.count(answered_case.distinct()).label("answered"),
        func.count(not_answered_case.distinct()).label("not_answered"),
        (
            1.0 * func.count(answered_case.distinct()) / func.count(main_query.c.question_number.distinct())
        ).label("progress"),
        func.count(main_query.c.question_number.distinct()).label("overall_questions"),
        func.sum(main_query.c.average_answer_length_ms).label("stage_answers_length_ms"),
        case(
                (func.sum(main_query.c.average_answer_length_ms) >= 60000, ".above"),  
                else_=".below"
            ).label("class"),
    ).group_by(main_query.c.stage_id)
    
    return result_query