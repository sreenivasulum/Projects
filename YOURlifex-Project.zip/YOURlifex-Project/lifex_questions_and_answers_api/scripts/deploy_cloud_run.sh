#!/bin/bash
set -e
if [ "$1" == "deploy" ]; then
    # Build the environment variable string
    ENV_VARS=$(grep -v '^#' .env.dev | xargs | tr ' ' ',')

    # Google Cloud Run deployment
    gcloud run deploy lifex-backend-api-v1 --source . \
        --update-env-vars "$ENV_VARS" \
        --allow-unauthenticated \
        --vpc-connector alloydb-connector \
        --platform managed \
        --memory 1Gi \
        --region europe-west2 \
        --min-instances=2 \
        --max-instances=10

    # Firebase deployment (assuming you have the Firebase CLI set up)
    cd app_deployment/firebase_hosting_dev && bash deploy.sh
else
    echo "Usage: ./deploy_script.sh deploy"
fi