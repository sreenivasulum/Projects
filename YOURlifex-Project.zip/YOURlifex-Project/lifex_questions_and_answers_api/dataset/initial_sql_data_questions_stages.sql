--
-- PostgreSQL database dump
--

-- Dumped from database version 15.5 (Debian 15.5-1.pgdg120+1)
-- Dumped by pg_dump version 15.5 (Debian 15.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


--
-- Data for Name: question_stages; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.question_stages (id, stage_name, time_created) FROM stdin;
1	Your Basic Information	2024-02-07 01:28:12.4016
2	Your Family Story and Family History	2024-02-07 01:28:12.4016
3	Your Story	2024-02-07 01:28:12.4016
4	The BiG 5	2024-02-07 01:28:12.4016
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.questions (id, time_created, question, stage_id) FROM stdin;
61	2024-02-07 01:31:29.601506	What is your full name?	1
62	2024-02-07 01:31:29.601506	What do most people call you?	1
63	2024-02-07 01:31:29.601506	What town do you live in?	1
64	2024-02-07 01:31:29.601506	What date is your birthday? Did your parents tell you anything memorable about your birthday such as; the weather conditions, or where you were born?	1
65	2024-02-07 01:31:29.601506	How old are you?	1
66	2024-02-07 01:31:29.601506	What star sign are you?	1
67	2024-02-07 01:31:29.601506	Aproximately how tall are you?	1
68	2024-02-07 01:31:29.601506	Aproximately what shoe size are you?	1
69	2024-02-07 01:31:29.601506	What's your hair colour?	1
70	2024-02-07 01:31:29.601506	What's your eye colour?	1
71	2024-02-07 01:31:29.601506	What's your favourite colour?	1
72	2024-02-07 01:31:29.601506	What's your religion?	1
73	2024-02-07 01:31:29.601506	Which country and town were you originally born in?	1
74	2024-02-07 01:31:29.601506	Where was the first house you lived in?  Do you have any memories from that house?	1
75	2024-02-07 01:31:29.601506	What schools do you remember going to ?	1
76	2024-02-07 01:31:29.601506	Do you have any sayings that you use with friends and family that they would recognise you by?	1
77	2024-02-07 01:31:29.601506	Have you ever had any pets? If so, what were they and what were their names? 	1
78	2024-02-07 01:31:29.601506	Do you have a favourite book? If yes, why do you like it? 	1
79	2024-02-07 01:31:29.601506	Do you have a favourite sport and sports team?	1
80	2024-02-07 01:31:29.601506	Do you have a favourite alcoholic drink?	1
81	2024-02-07 01:31:29.601506	What do you typically have for breakfast?	1
82	2024-02-07 01:31:29.601506	What are your top 3 favourite foods?	1
83	2024-02-07 01:31:29.601506	What are your top 3 favourite films? Why do you like them so much?	1
84	2024-02-07 01:31:29.601506	What are your top 3 favourite songs and who are they by?	1
85	2024-02-07 01:31:29.601506	Do you have a lucky number?	1
86	2024-02-07 01:31:29.601506	What is your favourite topic of conversation?	1
87	2024-02-07 01:31:29.601506	How do you relax? Do you have any notable hobbies? What do you like to do with any free time?	1
88	2024-02-07 01:31:29.601506	Do you prefer baths or showers, and why?	1
89	2024-02-07 01:31:29.601506	Do you prefer sunrises, or sunsets, and why?	1
90	2024-02-07 01:31:29.601506	Is there anything else you would like to add to your 'Basic Informtation' Stage? 	1
109	2024-02-07 01:48:40.46746	What are you mother and fathers names and birthdays?	2
110	2024-02-07 01:48:40.46746	What do, did, they both do for work?	2
111	2024-02-07 01:48:40.46746	Have they instilled any values in you that think have helped you in your life? If yes, what are they?	2
112	2024-02-07 01:48:40.46746	What do, or did, you admire most about your parents?	2
113	2024-02-07 01:48:40.46746	Do you have any memories, stories about your parents, and/or grandparents that you would like to add to your Story?	2
114	2024-02-07 01:48:40.46746	Do you have any children? What are their names and birthdays	2
115	2024-02-07 01:48:40.46746	Do you have 'pet' names for your children?	2
116	2024-02-07 01:48:40.46746	Do you have any brothers or sisters? If yes, what are their names? 	2
117	2024-02-07 01:48:40.46746	Are you married, or, with a close partner? If yes, what's their name? 	2
118	2024-02-07 01:48:40.46746	How long have you been married, or been together?	2
119	2024-02-07 01:48:40.46746	(If partnered) Where did you meet your spouse or partner?	2
120	2024-02-07 01:48:40.46746	Where did you get married?	2
121	2024-02-07 01:48:40.46746	Did you go anywhere on a honeymoon?	2
122	2024-02-07 01:48:40.46746	Can you share heartwarming, or funny family stories, that you hold dear?	2
123	2024-02-07 01:48:40.46746	Do you have any family goals, or plans for the future?	2
124	2024-02-07 01:48:40.46746	What do you envision and hope for your family's future?	2
125	2024-02-07 01:48:40.46746	Do you have a family tree? If yes, it would be a great addition to add to Your Story.	2
126	2024-02-07 01:48:40.46746	What else would like to add to your 'Family Life and Family History' Stage? This is so valuable for you to share, so please feel free to talk about anything you think would be useful, funny, interesting or things and moments that you are proud for your family to know. Take a minute here, let your thoughts wander - we have time..	2
127	2024-02-07 01:57:57.365466	Have you ever had any brushes with the law?	3
128	2024-02-07 01:57:57.365466	Are there any causes or charities that you are passionate about?	3
129	2024-02-07 01:57:57.365466	Are there any personal goals or aspirations you're currently working toward?	3
130	2024-02-07 01:57:57.365466	Are there any places you've traveled to that left a lasting impression on you?	3
131	2024-02-07 01:57:57.365466	Are you religious?	3
132	2024-02-07 01:57:57.365466	Can you share a memorable childhood experience or a significant life event that shaped who you are today?	3
133	2024-02-07 01:57:57.365466	Describe your perfect day.	3
134	2024-02-07 01:57:57.365466	Did you meet any important people to you during your career? If yes, who were they and why were they important to you?	3
135	2024-02-07 01:57:57.365466	Do you believe in astrology? Why or why not?	3
136	2024-02-07 01:57:57.365466	Do you believe in true love or love at first sight?	3
137	2024-02-07 01:57:57.365466	Do you have a favorite childhood memory?	3
138	2024-02-07 01:57:57.365466	Do you hold grudges or do you let go of things easily?	3
139	2024-02-07 01:57:57.365466	Do you live by any particular mantra?	3
140	2024-02-07 01:57:57.365466	Do you often listen to your intuition?	3
141	2024-02-07 01:57:57.365466	Do you think people are made for each other?	3
142	2024-02-07 01:57:57.365466	Have you ever flown a kite? If so, where and who with?	3
143	2024-02-07 01:57:57.365466	Have you ever had a spiritual experience? If yes, would you mind sharing it?	3
144	2024-02-07 01:57:57.365466	Have you ever lived through a war, what was it like?	3
145	2024-02-07 01:57:57.365466	How did you get your first job? What and where was it? Did you enjoy it?	3
146	2024-02-07 01:57:57.365466	How do I know when ive met the right person ?	3
147	2024-02-07 01:57:57.365466	How do you define beauty in another person?	3
148	2024-02-07 01:57:57.365466	How do you express your love for someone?	3
149	2024-02-07 01:57:57.365466	How do you hope people describe you?	3
150	2024-02-07 01:57:57.365466	How have your values changed from ten years ago? If so, how and why?	3
151	2024-02-07 01:57:57.365466	How important is it to be loved by someone?	3
152	2024-02-07 01:57:57.365466	How important is money and explain your views on this?	3
153	2024-02-07 01:57:57.365466	How often should a couple argue or fight to maintain a healthy relationship?	3
154	2024-02-07 01:57:57.365466	How would you spend your last day on earth?	3
155	2024-02-07 01:57:57.365466	If a crystal ball could tell you the truth about yourself, your life, the future, or anything else, what would you want to know?	3
156	2024-02-07 01:57:57.365466	If money were no object, what’s the first thing you would buy?	3
157	2024-02-07 01:57:57.365466	If raindrops weren’t a thing, what would you want to fall from the sky?	3
158	2024-02-07 01:57:57.365466	If you could choose a superpower, what would you pick?	3
159	2024-02-07 01:57:57.365466	If you could have dinner with anyone dead or alive, who would it be?	3
160	2024-02-07 01:57:57.365466	If you could jump into a pool of anything, what would it be full of?	3
161	2024-02-07 01:57:57.365466	If you had the opportunity to redesign society, what would you change?	3
162	2024-02-07 01:57:57.365466	If you have the opportunity to know the future, would you want to know?	3
163	2024-02-07 01:57:57.365466	If you ruled the world, what are the first two rules you would make law and why?	3
164	2024-02-07 01:57:57.365466	In life should you follow your heart, your head, or both? If both, how can that be done?	3
165	2024-02-07 01:57:57.365466	In what scenario, if any, is it okay to lie?	3
166	2024-02-07 01:57:57.365466	In your opinion, can long-distance relationships survive?	3
167	2024-02-07 01:57:57.365466	Is how you define success different today than it was when you were younger? if yes, how so?	3
168	2024-02-07 01:57:57.365466	Looking back, what are the important moments in your career and work life? What lessons have have you learnt along the way, good or tough, specifically about working life? Take your time here, this is real wisdom and experience your sharing!	3
169	2024-02-07 01:57:57.365466	Take four minutes and tell your life story in as much detail as possible.	3
170	2024-02-07 01:57:57.365466	Talk about your early years, what do you remember about going to schools, what lessons did you enjoy most, were there any memorable teachers or school experiences?	3
171	2024-02-07 01:57:57.365466	What advice would you give a family member who was about to become a parent for the first time?	3
172	2024-02-07 01:57:57.365466	What are the pro's and con's of getting married?	3
173	2024-02-07 01:57:57.365466	What are you most grateful for in life?	3
174	2024-02-07 01:57:57.365466	What are you most proud of in terms of your career and working life?	3
175	2024-02-07 01:57:57.365466	What are your core values or beliefs that are important to you?	3
176	2024-02-07 01:57:57.365466	What are your favorite ways to relax and unwind after a long day?	3
177	2024-02-07 01:57:57.365466	What are your future plans or dreams?	3
178	2024-02-07 01:57:57.365466	What are your hobbies and interests?	3
179	2024-02-07 01:57:57.365466	What brings you the most joy?	3
180	2024-02-07 01:57:57.365466	What did you want to do when you left school and what did you actually do in those early years after, achool or college?	3
181	2024-02-07 01:57:57.365466	What do you consider your core values?	3
182	2024-02-07 01:57:57.365466	What do you love most about life?	3
183	2024-02-07 01:57:57.365466	What do you think happens to us when we pass away?	3
184	2024-02-07 01:57:57.365466	What do you think it means to be healthy?	3
185	2024-02-07 01:57:57.365466	What do you think makes someone a good person?	3
186	2024-02-07 01:57:57.365466	What do you think people will be nostalgic for in 200 years?	3
187	2024-02-07 01:57:57.365466	What does friendship mean to you?	3
188	2024-02-07 01:57:57.365466	What impresses you the most?	3
189	2024-02-07 01:57:57.365466	What is happening in the news today - feel free to look at a newspaper or website? What are you views on whats happening?	3
190	2024-02-07 01:57:57.365466	What is one thing you think most people have and never appreciate enough?	3
191	2024-02-07 01:57:57.365466	What is something people would never guess just by looking at you?	3
192	2024-02-07 01:57:57.365466	What is the best concert you’ve ever attended?	3
193	2024-02-07 01:57:57.365466	What is the best thing and worst thing about being in love>	3
194	2024-02-07 01:57:57.365466	What is the most important lesson to teach a child?	3
195	2024-02-07 01:57:57.365466	What is the most important thing in a relationship? (e.g. trust, respect, etc.)	3
196	2024-02-07 01:57:57.365466	What is the weirdest thing in your home?	3
197	2024-02-07 01:57:57.365466	What is your approach to handling challenges or difficult situations in life?	3
198	2024-02-07 01:57:57.365466	What is your number one goal in life?	3
199	2024-02-07 01:57:57.365466	What lessons have you learnt about being a father or mother?	3
200	2024-02-07 01:57:57.365466	What makes you laugh the most?	3
201	2024-02-07 01:57:57.365466	What piece of advice would u give your 18 year old self	3
202	2024-02-07 01:57:57.365466	What should I do when I have troubles in my relationship ?	3
203	2024-02-07 01:57:57.365466	What three words would you use to describe yourself?	3
204	2024-02-07 01:57:57.365466	What was life like before the internet? How did you stay in touch? Was it better before the internet?	3
205	2024-02-07 01:57:57.365466	What would be the funniest superpower?	3
206	2024-02-07 01:57:57.365466	What would you like people to remember you for?	3
207	2024-02-07 01:57:57.365466	What would you say are the top 3 news stories of your lifetime and where were u what do u think happened	3
208	2024-02-07 01:57:57.365466	What’s a dealbreaker for you in a relationship?	3
209	2024-02-07 01:57:57.365466	What's it like being alive in these times?	3
210	2024-02-07 01:57:57.365466	What’s more important in life: excitement or stability? Why?	3
211	2024-02-07 01:57:57.365466	What’s something you’re really bad at?	3
212	2024-02-07 01:57:57.365466	What’s the best gift you’ve ever received and why?	3
213	2024-02-07 01:57:57.365466	What’s the quickest way someone can lose your trust?	3
214	2024-02-07 01:57:57.365466	What’s the weirdest fact you know?	3
215	2024-02-07 01:57:57.365466	What’s your favourite childhood memory?	3
216	2024-02-07 01:57:57.365466	What’s your favourite nickname someone has given you and how did you get it?	3
217	2024-02-07 01:57:57.365466	What’s your favourite quality about yourself? Least favourite?	3
218	2024-02-07 01:57:57.365466	What’s your least favourite part about being you?	3
219	2024-02-07 01:57:57.365466	Whats the best bit of advice you were ever given	3
220	2024-02-07 01:57:57.365466	When, if ever, is it okay to break the law?	3
221	2024-02-07 01:57:57.365466	Where is the most beautiful place you have ever seen in person?	3
222	2024-02-07 01:57:57.365466	Where were you on 9/11 and what was it like to live through that day? What do you think changed from that day?	3
223	2024-02-07 01:57:57.365466	Who do you admire most and why?	3
224	2024-02-07 01:57:57.365466	Who would you choose if you could be friends with a fictional character?	3
225	2024-02-07 01:57:57.365466	Who would you elect the president of the internet?	3
226	2024-02-07 01:57:57.365466	Why are pizzas usually round?	3
227	2024-02-07 01:57:57.365466	Would you like to be famous? If yes, In what way?	3
228	2024-02-07 01:57:57.365466	Would you rather go back in time to see the dinosaurs or jump forward a thousand years to see our futuristic society?	3
\.

--
-- PostgreSQL database dump complete
--

