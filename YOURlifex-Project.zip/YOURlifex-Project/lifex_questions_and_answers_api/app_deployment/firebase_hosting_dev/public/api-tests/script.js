let mediaRecorder;
let chunks = [];
let websocket;

const startButton = document.getElementById('startRecording');
const stopButton = document.getElementById('stopRecording');
const stopWebSocketButton = document.getElementById('stopWebSocket'); // Add ID for this button

let question_input = 2
let stage_input = 0
let user_id_input = 'fd69a44d-d0e9-45f9-a948-30c270e7bacc'

const userIDInput = document.getElementById('userID');
const stageInput = document.getElementById('stage');
const questionInput = document.getElementById('question');


const questionFetch = document.getElementById('fetch_question');
const questionText = document.getElementById('question_text');





userIDInput.addEventListener('input', function() {
  user_id_input = this.value; // Update variable on input change
});

stageInput.addEventListener('input', function() {
  stage_input = this.value; // Update variable on input change
});

questionInput.addEventListener('input', function() {
  question_input = this.value; // Update variable on input change
});


const myHeaders = new Headers();
myHeaders.append("Content-Type", "application/json");
const requestOptions = {
  method: "GET",
  headers: myHeaders,
  redirect: "follow"
};



// fetch questions
questionFetch.addEventListener('click', async () => {
  await fetch("https://api-v1.yourlifex.com/api/v1/question/?stage=" + stage_input + "&question_number=" + question_input, requestOptions)
    .then(response => response.json())
    .then(data => {
      questionText.innerHTML = JSON.stringify(data);
    }).catch(error => {
      console.error("Error fetching data:", error); 
    });
})

//function to initialise socket connection
function initWebSocket() {
    url = "wss://lifex-backend-api-v1-aoomkpbnqq-nw.a.run.app/api/v1/ws/record_to_file/s" + stage_input + "q" + question_input + "?user_id=" + user_id_input
    websocket = new WebSocket(url);
    websocket.binaryType = 'arraybuffer'; // For efficient audio transmission

    // just loud enough for testing
    websocket.onmessage = (event) => {
        console.log('Received message:', event.data);
    };

    // Handle sending final audio data when WebSocket is open
    websocket.onopen = () => {
        console.log("WebSocket connection established.");
    }

    // Handle WebSocket closing
    websocket.onclose = () => {
        console.log("WebSocket connection closed.");
    }
}


// Function to start recording
startButton.addEventListener('click', () => {

    if (websocket !== undefined && websocket.readyState==1) {
        true;
    } else {
        initWebSocket();
    }

    // Start recording
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
            mediaRecorder = new MediaRecorder(stream);
            mediaRecorder.start();

            mediaRecorder.ondataavailable = (e) => {
                chunks.push(e.data);
                websocket.send(e.data); // Send audio chunks as they become available
            };
        })
        .catch(error => {
            console.error("Error accessing media devices:", error);
        });
});


// Function to stop recording
async function _stopRecording(exit = false) {
    if (exit && mediaRecorder.state === 'recording') {
      mediaRecorder.onstop = () => {
        chunks = []; 
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
      };
      mediaRecorder.stop();
    
  
    return new Promise((resolve) => {
      websocket.onmessage = (event) => {
        if (event.data === 'audio_binary_data current length1') {
          resolve(); // Resolve when the expected message arrives
        }
      };
    });
    } else if (exit) {
      mediaRecorder.stop();
      return new Promise((resolve)=>{
        resolve();
      })
    }
  }
  
  // Function to stop recording
stopButton.addEventListener('click', async () => {
    await mediaRecorder.stop(); 
});

// Function to stop WebSocket
stopWebSocketButton.addEventListener('click', async () => {
    await _stopRecording(true); // Send the 'exit' flag
    websocket_open = websocket.close();
    if (!websocket_open) {
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
    };
});
