#!/bin/bash
firebase deploy --only hosting --project lifex-backend